Zillow housing price data retrieved from:
https://www.kaggle.com/paultimothymooney/zillow-house-price-data

Dataset has been modified by removing unnecessary id columns.
Dataset has been modified by removing date columns before 2010.