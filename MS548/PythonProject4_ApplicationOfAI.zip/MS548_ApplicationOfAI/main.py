from program import ApiLibrarySetups

if __name__ == "__main__":
    lib = ApiLibrarySetups()
    lib.run()
