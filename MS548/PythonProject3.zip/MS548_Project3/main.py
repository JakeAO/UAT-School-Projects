from PythonBookAnalysis import AnalysisWrapper

if __name__ == '__main__':
    analyzer = AnalysisWrapper()
    analyzer.run()
