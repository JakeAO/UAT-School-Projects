from project2 import Project2


if __name__ == "__main__":
    proj2 = Project2()
    proj2.run()
