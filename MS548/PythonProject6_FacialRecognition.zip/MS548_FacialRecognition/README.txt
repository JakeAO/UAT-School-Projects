https://synchronic.uat.edu/courses/3953/assignments/141358?module_item_id=357532

MS548 Project 6 - Facial Recognition

Simple program that takes a number of images from disk and asks the
Azure Cognitive Services API to detect faces in them. Was planning
on doing a custom ML facial recognition deal until I realized that
would take upwards of a month to figure out and train.