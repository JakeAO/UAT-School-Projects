from assistant import Assistant

if __name__ == "__main__":
    lib = Assistant()
    lib.run()
