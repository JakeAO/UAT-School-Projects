﻿namespace SadPumpkin.Games.ThirtyDayHero.Core
{
    public enum CombatDifficulty
    {
        Easy = 0,
        Normal = 1,
        Hard = 2
    }
}