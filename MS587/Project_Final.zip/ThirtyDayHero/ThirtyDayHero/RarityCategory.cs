﻿namespace SadPumpkin.Games.ThirtyDayHero.Core
{
    public enum RarityCategory : uint
    {
        Common = 100,
        Uncommon = 50,
        Rare = 25,
        Legendary = 10
    }
}