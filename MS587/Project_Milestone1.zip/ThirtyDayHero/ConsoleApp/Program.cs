﻿namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            new ConsolePlayer();
        }
    }
}