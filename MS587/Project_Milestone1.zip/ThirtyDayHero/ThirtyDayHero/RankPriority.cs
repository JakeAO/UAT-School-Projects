﻿namespace ThirtyDayHero
{
    public enum RankPriority
    {
        A,
        B,
        C,
        D,
        F
    }
}