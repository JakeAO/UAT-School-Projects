﻿namespace ThirtyDayHero
{
    public interface IIdTracked
    {
        uint Id { get; }
    }
}