﻿namespace ThirtyDayHero
{
    public static class AbilityUtil
    {
        private static uint _nextId = 20000;
        public static uint NextId => ++_nextId;
        
        
    }
}