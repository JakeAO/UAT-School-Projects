﻿namespace ThirtyDayHero
{
    public interface IRequirementCalc
    {
        bool MeetsRequirement(ICharacterActor character);
    }
}