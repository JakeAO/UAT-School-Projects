﻿namespace SadPumpkin.Games.ThirtyDayHero.Core.Definitions.Items
{
    public static class TrinketDefinitions
    {
        public static readonly TrackableIdGenerator IdTracker = new TrackableIdGenerator(ConstantIds.ITEM_TRINKET);
    }
}