﻿namespace SadPumpkin.Games.ThirtyDayHero.Core.Definitions.Armors
{
    public static class HeavyDefinitions
    {
        public static readonly TrackableIdGenerator IdTracker = new TrackableIdGenerator(ConstantIds.ARMOR_HEAVY);

    }
}