﻿namespace SadPumpkin.Games.ThirtyDayHero.Core.Definitions.Armors
{
    public static class MediumDefinitions
    {
        public static readonly TrackableIdGenerator IdTracker = new TrackableIdGenerator(ConstantIds.ARMOR_MEDIUM);

    }
}