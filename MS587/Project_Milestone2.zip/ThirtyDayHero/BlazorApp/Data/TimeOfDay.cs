﻿using System;

namespace SadPumpkin.Games.ThirtyDayHero.BlazorApp.Data
{
    public enum TimeOfDay
    {
        Morning = 0,
        Evening = 1,
        Night = 2
    }
}