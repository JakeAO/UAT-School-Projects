var mongo = require('mongodb');

var mongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

mongoClient.connect(url, function(err, db) {
    if(err)
        console.error(err);
    console.log("db success");
    
    var dbo = db.db("mydb");
    // dbo.createCollection("customers", function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log("col success");
        
    //     db.close();
    // })

    var col = dbo.collection("customers");
    // var newCustomer = {name: 'Dame Lamb', address: '159 Pasture'};
    // col.insertOne(newCustomer, function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log("insert success, new id: " + res.insertedId);
    // });
    
    // Delete
    // var deleteQuery = { address: /^123/ };
    // col.deleteMany(deleteQuery, function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log("deleted " + res.deletedCount + " entry");
    // });

    // Update
    // var updateQuery = { address: "654 Smush" };
    // var updateValue = { $set: { address: "456 Smush" } };
    // col.updateMany(updateQuery, updateValue, function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log(res.modifiedCount + " entries modified");
    // });

    // Query
    var noQuery = {}; // FindAll
    var query = { address: "123 Blarg" };
    var queryRegex = { address: /^123/ };
    var sort = { address: 1 };
    col.find(noQuery)
        .sort(sort)
        .limit(10)
        .toArray(function(err, res) {
        if(err)
            console.error(err);
        console.log(res);
    });

    //db.close();
});