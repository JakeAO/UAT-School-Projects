var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "test",
    password: "test",
    database: "newdb"
});

con.connect(function(err) {
    if(err)
        console.error(err);
    console.log("success");

    // con.query("INSERT INTO customers (name, address) VALUES ('Gronk', '852 Road')", function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log(res);
    // });

    // con.query("UPDATE customers SET address = 'Baggery 987' WHERE address = '123 Somewhere'", function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log(res);
    // });

    // var sql = "DELETE FROM customers WHERE id < 4";
    // con.query(sql, function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log(res);
    // });

    con.query("SELECT * FROM customers ORDER BY address", function(err, res) {
        if(err)
            console.error(err);
        console.log(res);
    });

    // con.query("SELECT * FROM customers", function(err, res) {
    //     if(err)
    //         console.error(err);
    //     console.log(res);
    // });
});