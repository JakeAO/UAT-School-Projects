package com.sadpumpkin.farm2table;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Collections;

public class UpdateEventer implements Handler.Callback {

    public static final int DEFAULT_TICK = 33;

    private boolean _paused = false;
    private Handler _handler = null;
    private long _idealTick = 33;
    private ArrayList<UpdateTickListener> _tickListeners = new ArrayList<>(5);

    public UpdateEventer(long idealTick, UpdateTickListener... listeners) {
        _handler = new Handler(Looper.getMainLooper(), this);
        _idealTick = idealTick;
        Collections.addAll(_tickListeners, listeners);

        sendMessage();
    }

    public boolean getPaused() {
        return _paused;
    }

    public void setPaused(boolean paused) {
        if (_paused != paused) {
            _paused = paused;
            if (!_paused) {
                sendMessage();
            }
        }
    }

    private void fireEvents(long timeStepMs) {
        for (UpdateTickListener listener : _tickListeners) {
            listener.onTick(timeStepMs);
        }
    }

    private void sendMessage() {
        Message message = new Message();
        message.obj = SystemClock.elapsedRealtime();

        _handler.sendMessageDelayed(message, _idealTick);
    }

    @Override
    public boolean handleMessage(@NonNull Message message) {
        long sendMs = (long) message.obj;
        long nowMs = SystemClock.elapsedRealtime();
        long elapsedMs = nowMs - sendMs;

        fireEvents(elapsedMs);
        if(!_paused) {
            sendMessage();
        }

        return true;
    }
}