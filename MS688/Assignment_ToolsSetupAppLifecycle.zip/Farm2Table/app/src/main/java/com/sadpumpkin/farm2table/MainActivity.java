package com.sadpumpkin.farm2table;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.Locale;

public class MainActivity extends Activity implements UpdateTickListener, View.OnClickListener {

    private UpdateEventer _updateEventer = null;

    private TextView _fpsValueLabel = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _updateEventer = new UpdateEventer(UpdateEventer.DEFAULT_TICK, this);
        _fpsValueLabel = findViewById(R.id.fpsValueLabel);

        findViewById(R.id.forageButton).setOnClickListener(this);
        findViewById(R.id.buildingButton).setOnClickListener(this);
        findViewById(R.id.inventoryButton).setOnClickListener(this);
        findViewById(R.id.settingsButton).setOnClickListener(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        _updateEventer.setPaused(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        _updateEventer.setPaused(false);
    }

    @Override
    public void onTick(long tickMs) {
        _fpsValueLabel.setText(String.format(Locale.getDefault(), "%.2f", (1000 / (float) tickMs)));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.forageButton: {
                Intent changeIntent = new Intent(this, ForageActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.buildingButton: {
                Intent changeIntent = new Intent(this, BuildingActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.inventoryButton: {
                Intent changeIntent = new Intent(this, InventoryActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.settingsButton: {
                Intent changeIntent = new Intent(this, SettingsActivity.class);
                startActivity(changeIntent);
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        // Intentionally left blank.
    }
}