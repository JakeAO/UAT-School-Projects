package com.sadpumpkin.farm2table;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class SplashActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        findViewById(R.id.spgButton).setOnClickListener(this);
        findViewById(R.id.playButton).setOnClickListener(this);
        findViewById(R.id.settingsButton).setOnClickListener(this);

        Log.d("Event", "onCreate");
    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.d("Event", "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.d("Event", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.d("Event", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();

        Log.d("Event", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("Event", "onDestroy");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.spgButton: {
                Intent changeIntent = new Intent(this, CreditsActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.playButton: {
                Intent changeIntent = new Intent(this, MainActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.settingsButton: {
                Intent changeIntent = new Intent(this, SettingsActivity.class);
                startActivity(changeIntent);
                break;
            }
        }
    }
}