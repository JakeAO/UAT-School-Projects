package com.sadpumpkin.farm2table;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SplashActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        findViewById(R.id.spgButton).setOnClickListener(this);
        findViewById(R.id.playButton).setOnClickListener(this);
        findViewById(R.id.settingsButton).setOnClickListener(this);

        AccountData accountData = GlobalDataYuck.getInstance().getAccountData();
        TextView accountIdView = findViewById(R.id.accountIdLabel);
        if (accountData != null) {
            accountIdView.setText(GlobalDataYuck.getInstance().getAccountData().getAccountId());
        } else {
            accountIdView.setText("Not logged in");
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.spgButton: {
                Intent changeIntent = new Intent(this, CreditsActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.playButton: {
                if(GlobalDataYuck.getInstance().getAccountData() == null) {
                    GlobalDataYuck.getInstance().tryFastLogin();
                }

                Intent changeIntent = new Intent(this, MainActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.settingsButton: {
                Intent changeIntent = new Intent(this, SettingsActivity.class);
                startActivity(changeIntent);
                break;
            }
        }
    }
}