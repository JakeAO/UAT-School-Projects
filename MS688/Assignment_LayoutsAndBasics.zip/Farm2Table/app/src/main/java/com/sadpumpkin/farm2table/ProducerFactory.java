package com.sadpumpkin.farm2table;

public class ProducerFactory implements IFactory {

    public ProducerFactory() {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getOutResource() {
        return null;
    }

    @Override
    public void tick() {

    }
}
