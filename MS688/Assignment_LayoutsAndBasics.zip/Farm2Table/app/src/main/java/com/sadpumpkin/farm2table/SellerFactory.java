package com.sadpumpkin.farm2table;

public class SellerFactory implements IFactory {

    public SellerFactory() {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getOutResource() {
        return "coin";
    }

    @Override
    public void tick() {

    }
}
