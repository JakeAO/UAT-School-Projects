package com.sadpumpkin.farm2table;

public interface IFactory {
    public String getName();
    public String getOutResource();
    public void tick();
}
