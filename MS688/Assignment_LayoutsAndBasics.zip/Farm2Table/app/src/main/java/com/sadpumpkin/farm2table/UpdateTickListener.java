package com.sadpumpkin.farm2table;

public interface UpdateTickListener {
    abstract void onTick(long tickMs);
}
