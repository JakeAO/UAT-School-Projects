package com.sadpumpkin.farm2table;

import java.util.ArrayList;

// TODO Figure out how to use JAVA better so this doesn't have to exist.
// This is anti-pattern af
public class GlobalDataYuck {
    private static GlobalDataYuck _instance = null;

    public static GlobalDataYuck getInstance() {
        if (_instance == null) {
            _instance = new GlobalDataYuck();
        }
        return _instance;
    }

    private UpdateEventer _updateEventer = null;
    private AccountData _accountData = null;
    private ArrayList<IFactory> _activeFactories = null;
    private long _currency = 1000;

    public GlobalDataYuck() {
        _activeFactories = new ArrayList<>(10);
        _updateEventer = new UpdateEventer(UpdateEventer.DEFAULT_TICK);
    }

    public UpdateEventer getEventer() {
        return _updateEventer;
    }

    public AccountData getAccountData() {
        return _accountData;
    }

    public AccountData tryFastLogin() {
        // TODO
        _accountData = new AccountData("DUMMY ACCOUNT ID");
        return _accountData;
    }

    public void addFactory(IFactory factory) {
        _activeFactories.add(factory);
    }

    public ArrayList<IFactory> getFactories() {
        return _activeFactories;
    }

    public long getCurrency() {
        return _currency;
    }
}