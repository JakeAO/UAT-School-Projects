package com.sadpumpkin.farm2table;

public class ConverterFactory implements IFactory {

    public ConverterFactory() {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getOutResource() {
        return null;
    }

    @Override
    public void tick() {

    }
}
