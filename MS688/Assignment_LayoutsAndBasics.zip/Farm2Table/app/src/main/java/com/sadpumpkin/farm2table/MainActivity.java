package com.sadpumpkin.farm2table;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.Locale;

public class MainActivity extends Activity implements UpdateTickListener, View.OnClickListener {

    private GlobalDataYuck _globalData = null;
    private UpdateEventer _updateEventer = null;
    private AccountData _accountData = null;

    private TextView _accountIdLabel = null;
    private TextView _coinsLabel = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _globalData = GlobalDataYuck.getInstance();
        _accountData = _globalData.getAccountData();
        _updateEventer = _globalData.getEventer();

        _updateEventer.addListener(this);

        findViewById(R.id.forageButton).setOnClickListener(this);
        findViewById(R.id.buildButton).setOnClickListener(this);
        findViewById(R.id.inventoryButton).setOnClickListener(this);
        findViewById(R.id.settingsButton).setOnClickListener(this);

        _accountIdLabel = findViewById(R.id.accountIdLabel);
        _coinsLabel = findViewById(R.id.coinsText);

        _accountIdLabel.setText(_accountData.getAccountId());
        _coinsLabel.setText(String.valueOf(_globalData.getCurrency()));
    }

    @Override
    protected void onPause() {
        super.onPause();
        _updateEventer.setPaused(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        _updateEventer.setPaused(false);
    }

    @Override
    public void onTick(long tickMs) {
        _coinsLabel.setText(String.valueOf(_globalData.getCurrency()));
        //_fpsValueLabel.setText(String.format(Locale.getDefault(), "%.2f", (1000 / (float) tickMs)));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        _updateEventer.removeListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.forageButton: {
                Intent changeIntent = new Intent(this, ForageActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.buildButton: {
                Intent changeIntent = new Intent(this, BuildingActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.inventoryButton: {
                Intent changeIntent = new Intent(this, InventoryActivity.class);
                startActivity(changeIntent);
                break;
            }
            case R.id.settingsButton: {
                Intent changeIntent = new Intent(this, SettingsActivity.class);
                startActivity(changeIntent);
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        // Intentionally left blank.
        // Avoid physical and virtual device back buttons from pushing us back to Splash.
    }
}