package com.sadpumpkin.farm2table;

public class AccountData {

    private String _accountId = null;

    public AccountData(String accountId) {
        _accountId = accountId;
    }

    public String getAccountId() {
        return "123456";
    }
}
