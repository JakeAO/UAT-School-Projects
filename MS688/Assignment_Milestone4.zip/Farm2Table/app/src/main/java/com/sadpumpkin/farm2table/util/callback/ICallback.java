package com.sadpumpkin.farm2table.util.callback;

public interface ICallback {
    void onInvoke();
}
