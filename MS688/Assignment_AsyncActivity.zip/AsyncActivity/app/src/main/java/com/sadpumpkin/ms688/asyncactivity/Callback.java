package com.sadpumpkin.ms688.asyncactivity;

public interface Callback {
    public abstract void onCalled();
}
