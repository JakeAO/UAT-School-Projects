package com.sadpumpkin.ms688.asyncactivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText waitTimeInput = null;
    private Button waitButton = null;

    private View progressParent = null;
    private ProgressBar progressBar = null;
    private TextView progressLabel = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        waitTimeInput = findViewById(R.id.waitTimeInput);
        waitButton = findViewById(R.id.waitButton);

        progressParent = findViewById(R.id.progressParent);
        progressBar = findViewById(R.id.progressBar);
        progressLabel = findViewById(R.id.progressLabel);

        waitTimeInput.setEnabled(true);
        waitButton.setEnabled(true);
        progressParent.setVisibility(View.INVISIBLE);

        waitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doWait();
            }
        });
    }

    private void doWait() {
        String waitTimeString = waitTimeInput.getText().toString();
        Long waitTime;
        try {
            waitTime = Long.parseLong(waitTimeString);
        } catch (NumberFormatException ex) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.errorTitle)
                    .setMessage(String.format("%s %s", getString(R.string.errorBody), waitTimeString))
                    .setCancelable(true)
                    .show();
            return;
        }

        waitTimeInput.setEnabled(false);
        waitButton.setEnabled(false);
        progressParent.setVisibility(View.VISIBLE);

        AsyncCountdown countdown = new AsyncCountdown(this,
                progressBar, progressLabel,
                waitTime, new Callback() {
            @Override
            public void onCalled() {
                waitTimeInput.setEnabled(true);
                waitButton.setEnabled(true);
                progressParent.setVisibility(View.INVISIBLE);
            }
        });
        countdown.execute();
    }
}