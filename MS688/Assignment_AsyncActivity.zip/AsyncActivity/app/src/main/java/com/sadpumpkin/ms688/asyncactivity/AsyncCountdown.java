package com.sadpumpkin.ms688.asyncactivity;

import android.app.Activity;
import android.os.AsyncTask;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;

public class AsyncCountdown extends AsyncTask<Void, Long, Void> {

    private WeakReference<Activity> _context = null;
    private WeakReference<ProgressBar> _progressBar = null;
    private WeakReference<TextView> _progressLabel = null;

    private Long _durationDs = null;
    private Callback _completionListener = null;

    public AsyncCountdown(Activity context,
                          ProgressBar progressBar, TextView progressLabel,
                          Long durationSec, Callback completionListener) {
        _context = new WeakReference<>(context);
        _progressBar = new WeakReference<>(progressBar);
        _progressLabel = new WeakReference<>(progressLabel);

        _durationDs = durationSec * 10;
        _completionListener = completionListener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        _progressBar.get().setMin(0);
        _progressBar.get().setMax(_durationDs.intValue());
        _progressBar.get().setProgress(0);

        _progressLabel.get().setText(String.format("%ss %s", _durationDs.toString(), _context.get().getString(R.string.remaining)));
    }

    @Override
    protected Void doInBackground(Void... voids) {
        for (long i = 0; i < _durationDs; i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            publishProgress(i);
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Long... values) {
        super.onProgressUpdate(values);

        Long value = values[0];

        Float updatedDurationSec = (_durationDs - value)/10f;

        _progressBar.get().setProgress(value.intValue());
        _progressLabel.get().setText(String.format("%ss %s", updatedDurationSec.toString(), _context.get().getString(R.string.remaining)));
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        if (_completionListener != null) {
            _completionListener.onCalled();
        }
    }
}