package com.sadpumpkin.ms688.navigationlists;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

public class SimpleContentActivity extends Activity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    int menuItemId = getIntent().getIntExtra("menu_item", -1);

    int titleTextId = 0;
    int alertTextId = R.string.alert_error;
    int iconId = 0;
    switch (menuItemId) {
      case R.id.menu_golems:
        titleTextId = R.string.menu_golems;
        alertTextId = R.string.alert_golems;
        iconId = R.drawable.ic_ice_golem;
        break;
      case R.id.menu_vikings:
        titleTextId = R.string.menu_viking;
        alertTextId = R.string.alert_viking;
        iconId = R.drawable.ic_viking_head;
        break;
      case R.id.menu_walruses:
        titleTextId = R.string.menu_walrus;
        alertTextId = R.string.alert_walrus;
        iconId = R.drawable.ic_walrus_head;
        break;
    }

    new AlertDialog.Builder(this)
            .setTitle(titleTextId)
            .setMessage(alertTextId)
            .setIcon(iconId)
            .setCancelable(true)
            .setOnCancelListener(new DialogInterface.OnCancelListener() {
              @Override
              public void onCancel(DialogInterface dialogInterface) {
                transitionBack();
              }
            })
            .show();
  }

  private void transitionBack() {
    startActivity(new Intent(this, EmPubLiteActivity.class));
  }
}