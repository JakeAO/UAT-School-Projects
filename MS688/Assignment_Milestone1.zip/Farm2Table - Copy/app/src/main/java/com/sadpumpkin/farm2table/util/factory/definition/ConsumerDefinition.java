package com.sadpumpkin.farm2table.util.factory.definition;

public class ConsumerDefinition extends BaseBuildingDefinition {

    private float _valueMultiplier = 1f;

    public ConsumerDefinition() {
        super();
        _valueMultiplier = 1f;
    }

    public ConsumerDefinition(String id, String name, Long duration, Long cost, String consumedId, float valueMultiplier) {
        super(id, name, duration, cost, consumedId);
        _valueMultiplier = valueMultiplier;
    }

    public float getValueMultiplier() {
        return _valueMultiplier;
    }

    public void setValueMultiplier(float valueMultiplier) {
        _valueMultiplier = valueMultiplier;
    }
}
