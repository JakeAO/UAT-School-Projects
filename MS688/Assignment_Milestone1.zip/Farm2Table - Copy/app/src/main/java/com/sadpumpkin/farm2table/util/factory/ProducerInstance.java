package com.sadpumpkin.farm2table.util.factory;

import com.google.firebase.Timestamp;

public class ProducerInstance extends BaseFactoryInstance {

    public ProducerInstance() {
        super();
    }
    public ProducerInstance(String factoryType, Timestamp lastStart, Long count) {
        super(factoryType, lastStart, count);
    }
}
