package com.sadpumpkin.farm2table.util;

import android.app.Activity;
import android.os.Handler;

import com.google.firebase.auth.FirebaseUser;
import com.sadpumpkin.farm2table.util.callback.ICallback2;

public class LoginReturning extends AsyncLoginBase {

    public LoginReturning(Handler handler, Activity context, FirebaseWrapper firebase, ICallback2<UserDataWrapper, GameDataWrapper> onDoneCallback) {
        super(handler, context, firebase, onDoneCallback);
    }

    @Override
    protected FirebaseUser onLogin() {
        return _firebase.get().auth().getCurrentUser();
    }
}
