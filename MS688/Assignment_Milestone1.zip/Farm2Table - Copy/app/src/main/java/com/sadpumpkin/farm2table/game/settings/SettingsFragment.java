package com.sadpumpkin.farm2table.game.settings;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.sadpumpkin.farm2table.MainActivity;
import com.sadpumpkin.farm2table.R;
import com.sadpumpkin.farm2table.util.AsyncLogout;
import com.sadpumpkin.farm2table.util.BaseFragment;
import com.sadpumpkin.farm2table.util.callback.ICallback;

public class SettingsFragment extends BaseFragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView textView = view.findViewById(R.id.text_home);
        textView.setText("Settings Fragment");

        Button signOutButton = view.findViewById(R.id.signOutButton);
        signOutButton.setOnClickListener(clickedView -> new Thread(new AsyncLogout(_handler, _activity, _firebase, _userData, new ICallback() {
            @Override
            public void onInvoke() {
                MainActivity.UserData = null;
                _mainNavController.navigate(R.id.splash_navigation);
            }
        })).start());
    }
}
