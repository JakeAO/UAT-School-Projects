package com.sadpumpkin.farm2table.util;

public class ResourceDefinition {

    private String _id = "";
    private String _name = "";
    private Long _basePrice = 1L;
    private String _storagePath = null;

    public ResourceDefinition() {
        _id = null;
        _name = "ERR";
        _basePrice = 1L;
        _storagePath = null;
    }

    public ResourceDefinition(String id, String name, Long basePrice, String storagePath) {
        _id = id;
        _name = name;
        _basePrice = basePrice;
        _storagePath = storagePath;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        _id = id;
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        _name = name;
    }

    public Long getBasePrice() {
        return _basePrice;
    }

    public void set_basePrice(Long basePrice){
        _basePrice = basePrice;
    }

    public String getPath() {
        return _storagePath;
    }

    public void setPath(String path) {
        _storagePath = path;
    }
}
