package com.sadpumpkin.farm2table.util;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Handler;
import android.util.Pair;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.sadpumpkin.farm2table.util.callback.ICallback2;

import java.lang.ref.WeakReference;

public abstract class AsyncLoginBase implements Runnable {

    protected WeakReference<Handler> _handler = null;
    protected WeakReference<Activity> _context = null;
    protected WeakReference<FirebaseWrapper> _firebase = null;
    protected ICallback2<UserDataWrapper, GameDataWrapper> _callback = null;

    protected ProgressDialog _progressDialog = null;

    public AsyncLoginBase(Handler handler, Activity context, FirebaseWrapper firebase, ICallback2<UserDataWrapper, GameDataWrapper> onDoneCallback) {
        _handler = new WeakReference<>(handler);
        _context = new WeakReference<>(context);
        _firebase = new WeakReference<>(firebase);
        _callback = onDoneCallback;
    }

    @Override
    public void run() {
        _handler.get().post(this::onPreExecute_mainThread);

        Pair<UserDataWrapper, GameDataWrapper> resultPair = null;
        try {
            resultPair = onExecute_backgroundThread();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        final UserDataWrapper finalUserData = resultPair.first;
        final GameDataWrapper finalGameData = resultPair.second;
        _handler.get().post(() -> onPostExecute_mainThread(finalUserData, finalGameData));
    }

    protected void onPreExecute_mainThread() {
        _progressDialog = new ProgressDialog(_context.get());
        _progressDialog.setCancelable(false);
        _progressDialog.setCanceledOnTouchOutside(false);
        _progressDialog.setMessage("");
        _progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        _progressDialog.show();
    }

    protected Pair<UserDataWrapper, GameDataWrapper> onExecute_backgroundThread() throws InterruptedException {
        _handler.get().post(() -> onProgress_mainThread("Logging In"));
        FirebaseUser user = onLogin();
        if (user == null)
            return null;

        Thread.sleep(100);

        _handler.get().post(() -> onProgress_mainThread("Syncing Game Data"));
        GameDataWrapper gameData = onSyncGameData();
        if (gameData == null)
            return null;

        Thread.sleep(100);

        _handler.get().post(() -> onProgress_mainThread("Syncing User Data"));
        FarmData farm = onSyncUserData(user, gameData);
        if (farm == null)
            return null;

        Thread.sleep(100);

        _handler.get().post(() -> onProgress_mainThread("Loading Farm"));

        Thread.sleep(100);

        return new Pair<>(new UserDataWrapper(user, farm), gameData);
    }

    protected void onProgress_mainThread(String status) {
        _progressDialog.setMessage(status);
    }

    protected void onPostExecute_mainThread(UserDataWrapper userData, GameDataWrapper gameData) {
        _progressDialog.dismiss();
        if (_callback != null) {
            _callback.onInvoke(userData, gameData);
        }
    }

    protected abstract FirebaseUser onLogin() throws InterruptedException;

    protected GameDataWrapper onSyncGameData() {
        // TODO Download Manifest.json
        // TODO Load and/or Download Assets from Storage
        return new GameDataWrapper(_firebase.get());
    }

    protected FarmData onSyncUserData(FirebaseUser user, GameDataWrapper gameData) throws InterruptedException {
        FirebaseWrapper fb = _firebase.get();
        DocumentReference docRef = fb.database()
                .collection("userData")
                .document(user.getUid());

        Task<DocumentSnapshot> getTask = docRef.get();
        while (!getTask.isComplete()) {
            Thread.sleep(100);
        }

        DocumentSnapshot docSnapshot = null;
        try {
            docSnapshot = getTask.getResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        if (!getTask.isSuccessful()) {
            return null;
        }

        FarmData farmData = null;
        if (docSnapshot.exists()) {
            farmData = docSnapshot.toObject(FarmData.class);
        } else {
            farmData = FarmData.BuildDefault();

            Task<Void> setTask = docRef.set(farmData);
            while (!setTask.isComplete()) {
                Thread.sleep(100);
            }
        }

        // TODO Use GameDataWrapper to load up definition data for instances and whatnot

        return farmData;
    }
}
