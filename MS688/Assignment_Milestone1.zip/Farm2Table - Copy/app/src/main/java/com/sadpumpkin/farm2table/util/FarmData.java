package com.sadpumpkin.farm2table.util;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.Timestamp;
import com.sadpumpkin.farm2table.util.factory.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FarmData {
    public static FarmData BuildDefault() {
        return new FarmData(
                1000L,
                new ArrayList<>(List.of(
                        new ProducerInstance("producer_A", Timestamp.now(), 1L),
                        new ProducerInstance("producer_B", Timestamp.now(), 2L)
                )),
                new ArrayList<>(List.of(
                        new ConverterInstance("converter_Ab", Timestamp.now(), 1L),
                        new ConverterInstance("converter_Ac", Timestamp.now(), 1L)
                )),
                new ArrayList<>(List.of(
                        new ConsumerInstance("consumer_A", Timestamp.now(), 1L),
                        new ConsumerInstance("consumer_C", Timestamp.now(), 1L)
                )),
                Map.of(
                        "resource_A", 5L,
                        "resource_B", 100L,
                        "resource_C", 15L,
                        "resource_D", 1L
                ),
                0f
        );
    }

    private Long coins = 1000L;
    private ArrayList<ProducerInstance> producers = new ArrayList<>();
    private ArrayList<ConverterInstance> converters = new ArrayList<>();;
    private ArrayList<ConsumerInstance> consumers = new ArrayList<>();;
    private HashMap<String, Long> inventory = new HashMap<>();
    private float prestige = 0f;

    public Long getCoins() {
        return coins;
    }

    public ArrayList<ProducerInstance> getProducers() {
        return producers;
    }

    public ArrayList<ConverterInstance> getConverters() {
        return converters;
    }

    public ArrayList<ConsumerInstance> getConsumers() {
        return consumers;
    }

    public HashMap<String, Long> getInventory() {
        return inventory;
    }

    public float getPrestige() {
        return prestige;
    }

    public FarmData() {

    }

    public FarmData(Long coins, List<ProducerInstance> producers, List<ConverterInstance> converters, List<ConsumerInstance> consumers, Map<String, Long> inventory, float prestige) {
        this.coins = coins;
        this.producers = new ArrayList<>(producers);
        this.converters = new ArrayList<>(converters);
        this.consumers = new ArrayList<>(consumers);
        this.inventory = new HashMap<>(inventory);
        this.prestige = prestige;
    }
}
