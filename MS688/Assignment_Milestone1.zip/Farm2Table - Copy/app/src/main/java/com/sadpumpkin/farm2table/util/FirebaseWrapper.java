package com.sadpumpkin.farm2table.util;

import android.app.Activity;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class FirebaseWrapper {
    private FirebaseAnalytics _analytics;
    private FirebaseAuth _auth;
    private FirebaseStorage _storage;
    private FirebaseFirestore _database;

    public FirebaseWrapper(Activity mainActivity) {
        _analytics = FirebaseAnalytics.getInstance(mainActivity);
        _auth = FirebaseAuth.getInstance();
        _storage = FirebaseStorage.getInstance();
        _database = FirebaseFirestore.getInstance();

        _database.enableNetwork();
    }

    public FirebaseAnalytics analytics() {
        return _analytics;
    }

    public FirebaseAuth auth() {
        return _auth;
    }

    public FirebaseStorage storage() {
        return _storage;
    }

    public FirebaseFirestore database() {
        return _database;
    }
}