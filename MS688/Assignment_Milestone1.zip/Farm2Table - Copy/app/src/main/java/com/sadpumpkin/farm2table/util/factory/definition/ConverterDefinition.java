package com.sadpumpkin.farm2table.util.factory.definition;

public class ConverterDefinition extends BaseBuildingDefinition {

    private String _producedId = "";

    public ConverterDefinition() {
        super();
        _producedId = "";
    }

    public ConverterDefinition(String id, String name, Long duration, Long cost, String consumedId, String producedId) {
        super(id, name, duration, cost, consumedId);
        _producedId = producedId;
    }

    public String getProducedId() {
        return _producedId;
    }

    public void setProducedId(String producedId) {
        _producedId = producedId;
    }
}
