package com.sadpumpkin.farm2table.util.factory.definition;

public abstract class BaseBuildingDefinition extends BaseFactoryDefinition {

    private Long _baseCost = 100L;
    private String _consumedId = "";

    protected BaseBuildingDefinition() {
        super();
        _baseCost = 100L;
        _consumedId = "";
    }

    protected BaseBuildingDefinition(String id, String name, Long duration, Long cost, String consumedId) {
        super(id, name, duration);
        _baseCost = cost;
        _consumedId = consumedId;
    }

    public Long getBaseCost() {
        return _baseCost;
    }

    public void setBaseCost(Long baseCost) {
        _baseCost = baseCost;
    }

    public String getConsumedId() {
        return _consumedId;
    }

    public void setConsumedId(String consumedId) {
        _consumedId = consumedId;
    }
}
