package com.sadpumpkin.farm2table.util;

import com.google.firebase.storage.StorageReference;
import com.sadpumpkin.farm2table.util.factory.definition.ConsumerDefinition;
import com.sadpumpkin.farm2table.util.factory.definition.ConverterDefinition;
import com.sadpumpkin.farm2table.util.factory.definition.ProducerDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GameDataWrapper {

    private FirebaseWrapper _firebase;

    private Map<String, ResourceDefinition> _knownResources = Map.of(
            "resource_A", new ResourceDefinition("resource_A", "Resource A", 1L, "Resources/RawProducts/Acorn.png"),
            "resource_B", new ResourceDefinition("resource_B", "Resource B", 2L, "Resources/RawProducts/AppleGreen.png"),
            "resource_C", new ResourceDefinition("resource_C", "Resource C", 5L, "Resources/RawProducts/Aubergine.png"),
            "resource_D", new ResourceDefinition("resource_D", "Resource D", 10L, "Resources/RawProducts/BeetGolden.png"));
    private Map<String, ProducerDefinition> _knownProducers = Map.of(
            "producer_A", new ProducerDefinition("producer_A", "Producer A", 15000L, "resource_A"),
            "producer_B", new ProducerDefinition("producer_B", "Producer B", 50000L, "resource_B"));
    private Map<String, ConverterDefinition> _knownConverters = Map.of(
            "converter_Ab", new ConverterDefinition("converter_Ab", "Converter A->B", 35000L, 1000L, "resource_A", "resource_B"),
            "converter_Ac", new ConverterDefinition("converter_Ac", "Converter A->C", 20000L, 1500L, "resource_A", "resource_C"),
            "converter_Cd", new ConverterDefinition("converter_Cd", "Converter C->D", 100000L, 2000L, "resource_C", "resource_D"));
    private Map<String, ConsumerDefinition> _knownConsumers = Map.of(
            "consumer_A", new ConsumerDefinition("consumer_A", "Consumer A", 5000L, 100L, "resource_A", 1f),
            "consumer_B", new ConsumerDefinition("consumer_B", "Consumer B", 5000L, 100L, "resource_B", 1f),
            "consumer_C", new ConsumerDefinition("consumer_C", "Consumer C", 5000L, 100L, "resource_C", 1f),
            "consumer_D", new ConsumerDefinition("consumer_D", "Consumer D", 5000L, 100L, "resource_D", 1f));

    public GameDataWrapper(FirebaseWrapper firebase) {
        _firebase = firebase;
    }

    public List<ResourceDefinition> getAllResources() {
        // TODO
        return new ArrayList<>(_knownResources.values());
    }

    public List<ProducerDefinition> getAllProducers() {
        // TODO
        return new ArrayList<>(_knownProducers.values());
    }

    public List<ConverterDefinition> getAllConverters() {
        // TODO
        return new ArrayList<>(_knownConverters.values());
    }

    public List<ConsumerDefinition> getAllConsumers() {
        // TODO
        return new ArrayList<>(_knownConsumers.values());
    }

    public StorageReference getImageReference(ResourceDefinition resource) {
        return _firebase.storage().getReference(resource.getPath());
    }

    public ResourceDefinition getResourceDefinition(String id) {
        // TODO
        if (_knownResources.containsKey(id))
            return _knownResources.get(id);
        return new ResourceDefinition();
    }

    public ProducerDefinition getProducerDefinition(String id) {
        // TODO
        if (_knownProducers.containsKey(id))
            return _knownProducers.get(id);
        return new ProducerDefinition();
    }

    public ConverterDefinition getConverterDefinition(String id) {
        // TODO
        if (_knownConverters.containsKey(id))
            return _knownConverters.get(id);
        return new ConverterDefinition();
    }

    public ConsumerDefinition getConsumerDefinition(String id) {
        // TODO
        if (_knownConsumers.containsKey(id))
            return _knownConsumers.get(id);
        return new ConsumerDefinition();
    }
}
