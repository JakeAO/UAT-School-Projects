package com.sadpumpkin.farm2table.util;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;

import androidx.annotation.NonNull;

import com.sadpumpkin.farm2table.util.callback.ICallback1;

import java.util.ArrayList;
import java.util.Collections;

public class UpdateEventer implements Handler.Callback {

    public static final int DEFAULT_TICK = 33;

    private boolean _paused = false;
    private Handler _handler = null;
    private long _idealTick = 33;
    private ArrayList<ICallback1<Integer>> _tickListeners = new ArrayList<>(5);

    public UpdateEventer(long idealTick, ICallback1<Integer>... listeners) {
        _handler = new Handler(Looper.getMainLooper(), this);
        _idealTick = idealTick;
        Collections.addAll(_tickListeners, listeners);

        sendMessage();
    }

    public void addListener(ICallback1<Integer> listener) {
        _tickListeners.add(listener);
    }

    public void removeListener(ICallback1<Integer> listener) {
        _tickListeners.remove(listener);
    }

    public boolean getPaused() {
        return _paused;
    }

    public void setPaused(boolean paused) {
        if (_paused != paused) {
            _paused = paused;
            if (!_paused) {
                sendMessage();
            }
        }
    }

    private void fireEvents(Integer timeStepMs) {
        for (ICallback1<Integer> listener : _tickListeners) {
            listener.onInvoke(timeStepMs);
        }
    }

    private void sendMessage() {
        Message message = new Message();
        message.obj = SystemClock.elapsedRealtime();

        _handler.sendMessageDelayed(message, _idealTick);
    }

    @Override
    public boolean handleMessage(@NonNull Message message) {
        long sendMs = (long) message.obj;
        long nowMs = SystemClock.elapsedRealtime();
        long elapsedMs = nowMs - sendMs;

        fireEvents(Math.toIntExact(elapsedMs));
        if (!_paused) {
            sendMessage();
        }

        return true;
    }
}