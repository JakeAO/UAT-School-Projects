package com.sadpumpkin.farm2table.util.factory.definition;

public class ProducerDefinition extends BaseFactoryDefinition {

    private String _producedId = "";

    public ProducerDefinition() {
        super();
        _producedId = "";
    }

    public ProducerDefinition(String id, String name, Long duration, String producedId) {
        super(id, name, duration);
        _producedId = producedId;
    }

    public String getProducedId() {
        return _producedId;
    }

    public void setProducedId(String producedId) {
        _producedId = producedId;
    }
}
