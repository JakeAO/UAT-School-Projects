package com.sadpumpkin.farm2table.util.factory.definition;

public abstract class BaseFactoryDefinition {

    private String _id = "";
    private String _name = "";
    private Long _durationMills = 30000L;

    protected BaseFactoryDefinition(){
        _id = null;
        _name = "ERR";
        _durationMills = 30000L;
    }
    protected BaseFactoryDefinition(String id, String name, Long duration) {
        _id = id;
        _name = name;
        _durationMills = duration;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        _id = id;
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        _name = name;
    }

    public Long getDurationMills() {
        return _durationMills;
    }

    public void setDurationMills(Long durationMills) {
        _durationMills = durationMills;
    }
}
