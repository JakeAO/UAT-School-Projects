package com.sadpumpkin.ms688.roomwithaview.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WordDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Word word);

    @Delete
    void delete(Word... words);

    @Query("DELETE FROM word_table")
    void deleteAll();

    @Query("SELECT * FROM word_table ORDER BY id ASC")
    LiveData<List<Word>> getWords();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void updateWord(Word... words);
}
