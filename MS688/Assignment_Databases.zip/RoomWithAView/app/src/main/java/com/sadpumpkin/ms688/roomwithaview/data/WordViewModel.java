package com.sadpumpkin.ms688.roomwithaview.data;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class WordViewModel extends AndroidViewModel {

    private WordRepository _repo;

    private LiveData<List<Word>> _allWords;

    public WordViewModel(Application application) {
        super(application);
        _repo = new WordRepository(application);
        _allWords = _repo.getAllWords();
    }

    public LiveData<List<Word>> getAllWords() {
        return _allWords;
    }

    public void insert(Word word) {
        _repo.insert(word);
    }

    public void delete(Word word) {
        _repo.delete(word);
    }

    public void deleteAll() {
        _repo.deleteAll();
    }

    public void update(Word word) {
        _repo.update(word);
    }
}
