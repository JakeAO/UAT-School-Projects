package com.sadpumpkin.ms688.roomwithaview;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.sadpumpkin.ms688.roomwithaview.data.Word;
import com.sadpumpkin.ms688.roomwithaview.data.WordListAdapter;
import com.sadpumpkin.ms688.roomwithaview.data.WordViewModel;

public class FirstFragment extends Fragment {

    private WordViewModel _wordViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        _wordViewModel = new ViewModelProvider(this).get(WordViewModel.class);

        final Activity activity = getActivity();
        final WordListAdapter adapter = new WordListAdapter(getActivity(), _wordViewModel);

        final ItemTouchHelper touchHelper = new ItemTouchHelper(
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        int position = viewHolder.getAdapterPosition();
                        Word word = adapter.getWordAtPosition(position);
                        _wordViewModel.delete(word);

                    }
                }
        );

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        touchHelper.attachToRecyclerView(recyclerView);

        Button insertButton = view.findViewById(R.id.insertButton);
        insertButton.setOnClickListener(clickedView ->
                Navigation
                        .findNavController(activity, R.id.nav_host_fragment)
                        .navigate(R.id.action_FirstFragment_to_SecondFragment));

        Button deleteAllButton = view.findViewById(R.id.deleteAllButton);
        deleteAllButton.setOnClickListener(clickedView -> {
            _wordViewModel.deleteAll();
            Snackbar.make(view, "Database cleared!", Snackbar.LENGTH_SHORT).show();
        });

        _wordViewModel.getAllWords().observe(getViewLifecycleOwner(), words -> adapter.setWords(words));
    }
}