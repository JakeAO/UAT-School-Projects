package com.sadpumpkin.ms688.roomwithaview.data;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class WordRepository {

    private WordDao _wordDao;
    private LiveData<List<Word>> _allWords;

    public WordRepository(Application application) {
        WordDatabase db = WordDatabase.getDatabase(application);
        _wordDao = db.wordDao();
        _allWords = _wordDao.getWords();
    }

    public LiveData<List<Word>> getAllWords() {
        return _allWords;
    }

    public void insert(Word word) {
        WordDatabase.writeExecutor.execute(() -> {
            _wordDao.insert(word);
        });
    }

    public void delete(Word word) {
        WordDatabase.writeExecutor.execute(() -> {
            _wordDao.delete(word);
        });
    }

    public void deleteAll() {
        WordDatabase.writeExecutor.execute(() -> {
            _wordDao.deleteAll();
        });
    }

    public void update(Word word) {
        WordDatabase.writeExecutor.execute(() ->{
            _wordDao.updateWord(word);
        });
    }
}
