package com.sadpumpkin.ms688.roomwithaview.data;

import android.content.Context;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.autofill.AutofillId;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sadpumpkin.ms688.roomwithaview.R;

import java.util.List;

public class WordListAdapter extends RecyclerView.Adapter<WordListAdapter.WordViewHolder> {

    class WordViewHolder extends RecyclerView.ViewHolder {
        private final TextView _idView;
        private final EditText _wordView;
        private final Button _deleteButton;

        private WordViewHolder(View view) {
            super(view);
            _idView = view.findViewById(R.id.idView);
            _wordView = view.findViewById(R.id.textView);
            _deleteButton = view.findViewById(R.id.deleteButton);
        }
    }

    private final LayoutInflater _inflater;
    private final WordViewModel _wordViewModel;

    private List<Word> _wordCache;

    public WordListAdapter(Context context, WordViewModel wordViewModel) {
        _inflater = LayoutInflater.from(context);
        _wordViewModel = wordViewModel;
    }

    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = _inflater.inflate(R.layout.view_word, parent, false);
        return new WordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {
        if (_wordCache != null) {
            Word current = _wordCache.get(position);
            holder._idView.setText(String.valueOf(current.getId()));
            holder._wordView.setInputType(InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE);
            holder._wordView.setText(current.getWord());
            holder._wordView.setOnEditorActionListener((TextView view, int actionId, KeyEvent event) -> {
                switch (actionId) {
                    case EditorInfo.IME_ACTION_DONE:
                    case EditorInfo.IME_ACTION_NEXT:
                        current.setWord(view.getText().toString());
                        _wordViewModel.update(current);
                        return true;
                }
                switch (event.getKeyCode()) {
                    case KeyEvent.KEYCODE_ENTER:
                    case KeyEvent.KEYCODE_NUMPAD_ENTER:
                        current.setWord(view.getText().toString());
                        _wordViewModel.update(current);
                        return true;
                }
                return false;
            });
            holder._deleteButton.setOnClickListener(clickedView -> _wordViewModel.delete(current));
        } else {
            holder._idView.setText("###");
            holder._wordView.setText("ERR");
            holder._wordView.setOnEditorActionListener((TextView view, int actionId, KeyEvent event) -> false);
            holder._deleteButton.setOnClickListener(clickedView -> {
            });
        }
    }

    @Override
    public int getItemCount() {
        return _wordCache != null ? _wordCache.size() : 0;
    }

    public void setWords(List<Word> words) {
        _wordCache = words;
        notifyDataSetChanged();
    }

    public Word getWordAtPosition(int position) {
        return _wordCache.get(position);
    }
}
