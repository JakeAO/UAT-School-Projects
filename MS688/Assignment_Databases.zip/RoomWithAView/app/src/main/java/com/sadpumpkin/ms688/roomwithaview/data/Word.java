package com.sadpumpkin.ms688.roomwithaview.data;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "word_table")
public class Word {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int _id;

    @NonNull
    @ColumnInfo(name = "word")
    private String _word;

    @Ignore
    public Word(@NonNull String word) {
        _word = word;
    }

    public Word(int id, @NonNull String word) {
        _id = id;
        _word = word;
    }

    public int getId() {
        return _id;
    }

    public void setId(int id) {
        _id = id;
    }

    public String getWord() {
        return _word;
    }

    public void setWord(String word) {
        _word = word;
    }
}
