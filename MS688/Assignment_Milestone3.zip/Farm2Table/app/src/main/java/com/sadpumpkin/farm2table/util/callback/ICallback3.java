package com.sadpumpkin.farm2table.util.callback;

public interface ICallback3<T1, T2, T3> {
    void onInvoke(T1 value1, T2 value2, T3 value3);
}