package com.sadpumpkin.farm2table.util.callback;

public interface ICallback2<T1, T2> {
    void onInvoke(T1 value1, T2 value2);
}
