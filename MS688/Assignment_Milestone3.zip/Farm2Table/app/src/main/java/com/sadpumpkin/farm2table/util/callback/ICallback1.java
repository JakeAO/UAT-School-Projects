package com.sadpumpkin.farm2table.util.callback;

public interface ICallback1<T1> {
    void onInvoke(T1 value1);
}
