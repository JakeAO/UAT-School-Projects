package com.sadpumpkin.farm2table;

import android.app.Application;

import dagger.hilt.android.AndroidEntryPoint;
import dagger.hilt.android.HiltAndroidApp;

@AndroidEntryPoint
@HiltAndroidApp
public class Farm2Table extends Application {

}
