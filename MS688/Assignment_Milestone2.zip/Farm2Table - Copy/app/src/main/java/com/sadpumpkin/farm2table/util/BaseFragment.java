package com.sadpumpkin.farm2table.util;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;

import com.sadpumpkin.farm2table.MainActivity;
import com.sadpumpkin.farm2table.game.GameFragment;

public class BaseFragment extends Fragment {

    protected Activity _activity;
    protected Handler _handler;
    protected FirebaseWrapper _firebase;
    protected UserDataWrapper _userData;
    protected GameDataWrapper _gameData;
    protected NavController _mainNavController;
    protected NavController _gameNavController;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // *Cries in programmer*

        _activity = getActivity();
        _handler = new Handler(Looper.getMainLooper());
        _firebase = MainActivity.Firebase;
        _userData = MainActivity.UserData;
        _gameData = MainActivity.GameData;
        _mainNavController = MainActivity.NavController;
        _gameNavController = GameFragment.NavController;
    }
}