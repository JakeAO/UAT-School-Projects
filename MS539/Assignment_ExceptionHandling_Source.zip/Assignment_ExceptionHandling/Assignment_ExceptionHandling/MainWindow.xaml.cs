﻿/////////////////////////////////
/// Jake O'Connor
/// UAT MS539
/// Assignment - Add Exception Handling
///
/// Initial Time Estimate: 1hr
/// Started Work: 5/21/20 ~11:30PM
/// Finished Work: 5/22/20 ~1:00AM
/// Discrepancy: ~30 min
/// Discrepancy Explanation: Getting the reflection to find the proper TryParse() method took 
///     slightly longer than expected, as MakeByRefType() tripped me up for a few minutes.
///     Also late into the process decided to relax the requirements around line ~78 to allow
///     either Parse() or TryParse() to satisfy the requirements to make it in the list, which
///     necessitated adding the event handler for the ListBox's selection changing and modifying
///     the Button states to prevent attempting a parse for which we had no known method.
///
/////////////////////////////////

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace Assignment_ExceptionHandling
{
    public partial class MainWindow : Window
    {
        private readonly IReadOnlyDictionary<string, (MethodInfo parse, MethodInfo tryParse)> _parseMethodsByName;

        public MainWindow()
        {
            InitializeComponent();

            Dictionary<string, (MethodInfo, MethodInfo)> parseMethodDictionary = new Dictionary<string, (MethodInfo, MethodInfo)>(10);
            foreach (Type type in Assembly.GetAssembly(typeof(byte)).GetTypes())
            {
                string name = type.Name;
                MethodInfo parseMethod = null, tryParseMethod = null;

                foreach (MethodInfo method in type.GetMethods(BindingFlags.Public | BindingFlags.Static))
                {
                    switch (method.Name)
                    {
                        case "Parse":
                            {
                                if (method.ReturnType != type)
                                    continue;
                                ParameterInfo[] methodParams = method.GetParameters();
                                if (methodParams.Length != 1)
                                    continue;
                                if (methodParams[0].ParameterType != typeof(string))
                                    continue;

                                parseMethod = method;
                                break;
                            }
                        case "TryParse":
                            {
                                if (method.ReturnType != typeof(Boolean))
                                    continue;
                                ParameterInfo[] methodParams = method.GetParameters();
                                if (methodParams.Length != 2)
                                    continue;
                                if (methodParams[0].ParameterType != typeof(string))
                                    continue;
                                if (!methodParams[1].IsOut)
                                    continue;
                                if (methodParams[1].ParameterType != type.MakeByRefType())
                                    continue;

                                tryParseMethod = method;
                                break;
                            }
                    }
                }

                if (parseMethod != null || tryParseMethod != null)
                {
                    parseMethodDictionary[name] = (parseMethod, tryParseMethod);
                }
            }

            _parseMethodsByName = parseMethodDictionary;
            typeSelectionListBox.ItemsSource = _parseMethodsByName.Keys;

            parseButton.IsEnabled = false;
            tryParseButton.IsEnabled = false;
        }

        private void typeSelectionListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool enableParse = false, enableTryParse = false;

            string typeName = typeSelectionListBox.SelectedItem as string;
            if (_parseMethodsByName.TryGetValue(typeName, out var methodPair))
            {
                enableParse = methodPair.parse != null;
                enableTryParse = methodPair.tryParse != null;
            }

            parseButton.IsEnabled = enableParse;
            tryParseButton.IsEnabled = enableTryParse;
        }

        private void parseButton_Click(object sender, RoutedEventArgs e)
        {
            string typeName = typeSelectionListBox.SelectedItem as string;
            string inputString = inputStringTextBox.Text;

            if (!_parseMethodsByName.TryGetValue(typeName, out var methodPair))
            {
                MessageBox.Show($"Somehow you selected \"{typeName}\" which isn't a supported type, please try again.", "Error: Unknown Type", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                object result = methodPair.parse.Invoke(null, new object[] { inputString });
                MessageBox.Show(
                    $"Successfully parsed input \"{inputString}\" into type {typeName} using {typeName}.Parse().\n\nResult: {result}",
                    $"{typeName}.Parse() Success",
                    MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                Exception innerEx = ex.InnerException ?? ex;
                MessageBox.Show(
                    $"Failed to parse input \"{inputString}\" into type {typeName} using {typeName}.Parse().\n\n{innerEx.GetType().Name} was encountered with message \"{innerEx.Message}\".",
                    $"{typeName}.Parse() Failed",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void tryParseButton_Click(object sender, RoutedEventArgs e)
        {
            string typeName = typeSelectionListBox.SelectedItem as string;
            string inputString = inputStringTextBox.Text;

            if (!_parseMethodsByName.TryGetValue(typeName, out var methodPair))
            {
                MessageBox.Show($"Somehow you selected \"{typeName}\" which isn't a supported type, please try again.", "Error: Unknown Type", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            object outValue = default;
            object result = methodPair.tryParse.Invoke(null, new object[] { inputString, outValue });

            if (result is bool boolResult && boolResult)
            {
                MessageBox.Show(
                        $"Successfully parsed input \"{inputString}\" into type {typeName} using {typeName}.TryParse().\n\nResult: {outValue}",
                        $"{typeName}.TryParse() Success",
                        MessageBoxButton.OK);
            }
            else
            {
                MessageBox.Show(
                    $"Failed to parse input \"{inputString}\" into type {typeName} using {typeName}.TryParse().",
                    $"{typeName}.TryParse() Failed",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}