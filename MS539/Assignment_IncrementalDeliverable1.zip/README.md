# Cryptid Corral
Create monsters by scanning .exe files on your computer, train them by investing time, currency, and love, battle them against randomly generated opponents in the colleseum, and combine them to create even more powerful monsters.

Cryptid Corral is an homage to classic games like Monster Rancher and Dragon Seeds built entirely in C# and WPF.
