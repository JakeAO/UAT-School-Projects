﻿namespace UAT_MS539.Core.Code.Cryptid
{
    public enum EHiddenStat
    {
        Morale = 0,
        Lifespan = 1,

        _Count
    }
}