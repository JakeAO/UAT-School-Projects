﻿using Discussion_Inheritance.Vehicle.Motor;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class NoMotorTests
    {
        [Test]
        public static void Constructor_Sets_Name_To_NoMotor()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual("NoMotor", instance.Name);
        }

        [Test]
        public static void Constructor_Sets_MinimumFuelUnits_To_Zero()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.MinimumFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_CurrentFuelUnits_To_Zero()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.CurrentFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_MaximumFuelUnits_To_Zero()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.MaximumFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_MaximumSpeedMph_To_Zero()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.MaximumSpeedMph);
        }

        [Test]
        public static void Constructor_SetsCurrentSpeedMph_To_Zero()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.CurrentSpeedMph);
        }

        [Test]
        public static void Constructor_Sets_FuelType_To_Invalid()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.AreEqual(FuelType.Invalid, instance.FuelType);
        }

        [Test]
        public static void Constructor_Sets_IsRunning_To_False()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(instance.IsRunning);
        }

        [Test]
        public static void Constructor_Sets_FuelConsumption_To_Null()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsNull(instance.FuelConsumptionAtSpeed);
        }

        [Test]
        public static void TryFuel_Always_Fails()
        {
            NoMotor instance = CreateDummyInstance();

            float fuelAmount = 5f;
            Assert.IsFalse(instance.TryFuel(FuelType.Invalid, ref fuelAmount));
        }

        [Test]
        public static void TryAccelerate_Always_Fails()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(instance.TryAccelerate());
        }

        [Test]
        public static void TryDecelerate_Always_Fails()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(instance.TryDecelerate());
        }

        [Test]
        public static void Start_Always_Fails()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(instance.Start());
        }

        [Test]
        public static void Stop_Always_Fails()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(instance.Stop());
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            NoMotor instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static NoMotor CreateDummyInstance() => new NoMotor();
    }
}