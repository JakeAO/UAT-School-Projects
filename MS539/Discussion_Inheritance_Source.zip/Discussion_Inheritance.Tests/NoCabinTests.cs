﻿using Discussion_Inheritance.Vehicle.Cabin;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class NoCabinTests
    {
        [Test]
        public static void Constructor_Sets_SeatCount_To_Zero()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.AreEqual(0, instance.SeatCount);
        }

        [Test]
        public static void Constructor_Sets_CupHolderCount_To_Zero()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.AreEqual(0, instance.CupHolderCount);
        }

        [Test]
        public static void Constructor_Sets_HasPowerWindows_To_False()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.IsFalse(instance.HasPowerWindows);
        }

        [Test]
        public static void Constructor_Sets_HasPowerLocks_To_False()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.IsFalse(instance.HasPowerLocks);
        }

        [Test]
        public static void Constructor_Sets_SafetyFeatures_To_Invalid()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.AreEqual(SafetyFeatureType.Invalid, instance.SafetyFeatures);
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            NoCabin instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static NoCabin CreateDummyInstance() => new NoCabin();
    }
}