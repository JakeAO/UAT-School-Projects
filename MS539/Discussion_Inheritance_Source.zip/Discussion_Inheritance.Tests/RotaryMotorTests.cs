﻿using System;
using Discussion_Inheritance.Vehicle.Motor;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class RotaryMotorTests
    {
        private const uint DUMMY_ROTORS = 1u;
        private const uint DUMMY_CYLINDERS = 5u;
        private const string DUMMY_NAME = "testRotaryName";
        private const float DUMMY_MAX_SPEED = 100f;
        private static readonly Func<float, float> DUMMY_FUEL_CONSUMPTION = speedMph => 0.5f;
        private const FuelType DUMMY_FUEL_TYPE = FuelType.Gasoline;
        private const float DUMMY_MAX_FUEL = 10f;
        private const float DUMMY_MIN_FUEL = 0.5f;

        [Test]
        public static void Constructor_Sets_Name()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_NAME, instance.Name);
        }

        [Test]
        public static void Constructor_Sets_MinimumFuelUnits()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_MIN_FUEL, instance.MinimumFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_Rotors()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_ROTORS, instance.RotorCount);
        }

        [Test]
        public static void Constructor_Sets_CylindersPerRotor()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_CYLINDERS, instance.CylindersPerRotor);
        }

        [Test]
        public static void Constructor_Sets_CurrentFuelUnits()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.CurrentFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_MaximumFuelUnits()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_MAX_FUEL, instance.MaximumFuelUnits);
        }

        [Test]
        public static void Constructor_Sets_MaximumSpeedMph()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_MAX_SPEED, instance.MaximumSpeedMph);
        }

        [Test]
        public static void Constructor_SetsCurrentSpeedMph()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.CurrentSpeedMph);
        }

        [Test]
        public static void Constructor_Sets_FuelType()
        {
            var instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_FUEL_TYPE, instance.FuelType);
        }

        [Test]
        public static void Constructor_Sets_IsRunning()
        {
            var instance = CreateDummyInstance();

            Assert.IsFalse(instance.IsRunning);
        }

        [Test]
        public static void Constructor_Sets_FuelConsumption()
        {
            var instance = CreateDummyInstance();

            Assert.AreSame(DUMMY_FUEL_CONSUMPTION, instance.FuelConsumptionAtSpeed);
        }

        [Test]
        public static void TryFuel_Succeeds_With_Valid_Fuel()
        {
            var instance = CreateDummyInstance();

            float fuelAmount = 1f;
            Assert.IsTrue(instance.TryFuel(DUMMY_FUEL_TYPE, ref fuelAmount));
        }

        [Test]
        public static void TryFuel_Fails_With_Invalid_Fuel()
        {
            var instance = CreateDummyInstance();

            float fuelAmount = 1f;
            Assert.IsFalse(instance.TryFuel(FuelType.Invalid, ref fuelAmount));
        }

        [Test]
        public static void TryFuel_Fails_When_Full()
        {
            var instance = CreateDummyInstance();

            float fuelAmount = DUMMY_MAX_FUEL;
            instance.TryFuel(DUMMY_FUEL_TYPE, ref fuelAmount);

            fuelAmount = DUMMY_MAX_FUEL;
            Assert.IsFalse(instance.TryFuel(DUMMY_FUEL_TYPE, ref fuelAmount));
        }

        [Test]
        public static void TryAccelerate_Fails_If_Not_Running()
        {
            var instance = CreateDummyInstance();

            Assert.IsFalse(instance.TryAccelerate());
        }

        [Test]
        public static void TryAccelerate_Succeeds_If_Fueled_and_Running()
        {
            var instance = CreateDummyInstance();

            float fuelAmount = DUMMY_MAX_FUEL;
            instance.TryFuel(DUMMY_FUEL_TYPE, ref fuelAmount);
            instance.Start();
            
            Assert.IsTrue(instance.TryAccelerate());
        }

        [Test]
        public static void TryDecelerate_Fails_If_Stopped()
        {
            var instance = CreateDummyInstance();

            Assert.IsFalse(instance.TryDecelerate());
        }

        [Test]
        public static void TryDecelerate_Succeeds_If_Running_And_Moving()
        {
            var instance = CreateDummyInstance();

            float fuelAmount = DUMMY_MAX_FUEL;
            instance.TryFuel(DUMMY_FUEL_TYPE, ref fuelAmount);
            instance.Start();
            instance.TryAccelerate();
            instance.TryAccelerate();
            instance.TryAccelerate();

            Assert.IsTrue(instance.TryDecelerate());
        }

        [Test]
        public static void Start_Fails_If_Running()
        {
            var instance = CreateDummyInstance();

            instance.Start();

            Assert.IsFalse(instance.Start());
        }

        [Test]
        public static void Stop_Fails_If_Not_Running()
        {
            var instance = CreateDummyInstance();

            instance.Stop();

            Assert.IsFalse(instance.Stop());
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            var instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static RotaryMotor CreateDummyInstance() => new RotaryMotor(
            DUMMY_ROTORS, DUMMY_CYLINDERS,
            DUMMY_NAME, DUMMY_MAX_SPEED,
            DUMMY_FUEL_CONSUMPTION,
            DUMMY_FUEL_TYPE, DUMMY_MAX_FUEL, DUMMY_MIN_FUEL);
    }
}