﻿using System.Numerics;
using Discussion_Inheritance.Vehicle.Storage;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class NoStorageTests
    {
        [Test]
        public static void Constructor_Sets_MaxTonnage_To_Zero()
        {
            NoStorage instance = CreateDummyInstance();

            Assert.AreEqual(0f, instance.MaxTonnage);
        }

        [Test]
        public static void Constructor_Sets_InteriorDimensions_To_Vector3Zero()
        {
            NoStorage instance = CreateDummyInstance();

            Assert.AreEqual(Vector3.Zero, instance.InteriorDimensionsFeet);
        }

        [Test]
        public static void Constructor_Sets_ExposedToElements_To_False()
        {
            NoStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.ExposedToElements);
        }

        [Test]
        public static void CanFitCargo_Always_Returns_Null()
        {
            NoStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.CanFitCargo(Vector3.Zero, 0f));
            Assert.IsFalse(instance.CanFitCargo(Vector3.One * 1000f, 0f));
            Assert.IsFalse(instance.CanFitCargo(Vector3.Zero, 1000f));
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            NoStorage instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static NoStorage CreateDummyInstance() => new NoStorage();
    }
}