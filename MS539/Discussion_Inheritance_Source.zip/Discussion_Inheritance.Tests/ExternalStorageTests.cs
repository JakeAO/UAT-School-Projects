﻿using System.Numerics;
using Discussion_Inheritance.Vehicle.Storage;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class ExternalStorageTests
    {
        private const float DUMMY_TONNAGE = 1000f;
        private static readonly Vector3 DUMMY_DIMENSIONS = new Vector3(100, 100, 100);
        private static readonly Vector3 DUMMY_OVERFLOW = new Vector3(50, 50, 50);
        
        [Test]
        public static void Constructor_Sets_MaxTonnage()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_TONNAGE, instance.MaxTonnage);
        }

        [Test]
        public static void Constructor_Sets_InteriorDimensions()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_DIMENSIONS, instance.InteriorDimensionsFeet);
        }

        [Test]
        public static void Constructor_Sets_OverflowDimensions()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_OVERFLOW, instance.AllowedOverflowFeet);
        }

        [Test]
        public static void Constructor_Sets_ExposedToElements_To_True()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.ExposedToElements);
        }

        [Test]
        public static void CanFitCargo_Returns_False_If_Tonnage_Exceeded()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.CanFitCargo(Vector3.Zero, DUMMY_TONNAGE + 1f));
        }

        [Test]
        public static void CanFitCargo_Returns_False_If_Dimensions_Exceeded_With_Overflow()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.CanFitCargo(DUMMY_DIMENSIONS + DUMMY_OVERFLOW, 0f));
        }
        
        [Test]
        public static void CanFitCargo_Returns_True_If_Tonnage_Within_Bounds()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.CanFitCargo(Vector3.Zero, DUMMY_TONNAGE - 1f));
        }

        [Test]
        public static void CanFitCargo_Returns_True_If_Dimensions_Within_Bounds()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.CanFitCargo(DUMMY_DIMENSIONS * 0.99f, 0f));
            Assert.IsTrue(instance.CanFitCargo(DUMMY_DIMENSIONS * 0.5f, 0f));
            Assert.IsTrue(instance.CanFitCargo(Vector3.Zero, 0f));
        }

        [Test]
        public static void CanFitCargo_Returns_True_If_Dimensions_Within_Bounds_With_Overflow()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.CanFitCargo((DUMMY_DIMENSIONS + DUMMY_OVERFLOW) * 0.99f, 0f));
            Assert.IsTrue(instance.CanFitCargo((DUMMY_DIMENSIONS + DUMMY_OVERFLOW) * 0.5f, 0f));
            Assert.IsTrue(instance.CanFitCargo(Vector3.Zero, 0f));
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            ExternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static ExternalStorage CreateDummyInstance() => new ExternalStorage(DUMMY_TONNAGE, DUMMY_DIMENSIONS, DUMMY_OVERFLOW);
    }
}