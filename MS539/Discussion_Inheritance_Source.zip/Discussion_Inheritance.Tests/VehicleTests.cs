﻿using Discussion_Inheritance.Vehicle.Cabin;
using Discussion_Inheritance.Vehicle.Motor;
using Discussion_Inheritance.Vehicle.Storage;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class VehicleTests
    {
        private const uint DUMMY_YEAR = 1234;
        private const string DUMMY_MAKE = "testMake";
        private const string DUMMY_MODEL = "testModel";
        private const string DUMMY_SERIAL = "testSerial";
        private const float DUMMY_LENGTH = 800f;
        private const float DUMMY_WIDTH = 600f;
        private const float DUMMY_WEIGHT = 1000f;

        [Test]
        public static void Constructor_Sets_Year()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_YEAR, instance.Year);
        }

        [Test]
        public static void Constructor_Sets_Make()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_MAKE, instance.Make);
        }

        [Test]
        public static void Constructor_Sets_Model()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_MODEL, instance.Model);
        }

        [Test]
        public static void Constructor_Sets_Serial()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_SERIAL, instance.Serial);
        }

        [Test]
        public static void Constructor_Sets_Length()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_LENGTH, instance.LengthFeet);
        }

        [Test]
        public static void Constructor_Sets_Width()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_WIDTH, instance.WidthFeet);
        }

        [Test]
        public static void Constructor_Sets_Weight()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_WEIGHT, instance.CurbWeightPounds);
        }

        [Test]
        public static void Constructor_Sets_Motor()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.IsNotNull(instance.Motor);
        }

        [Test]
        public static void Constructor_Sets_Cabin()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.IsNotNull(instance.Cabin);
        }

        [Test]
        public static void Constructor_Sets_Storage()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();

            Assert.IsNotNull(instance.Storage);
        }

        [Test]
        public static void GetIdentifier_Is_Not_Null_Or_WhiteSpace()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();
            string identifier = instance.GetIdentifier();

            Assert.IsFalse(string.IsNullOrWhiteSpace(identifier));
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            Vehicle.Vehicle instance = CreateDummyInstance();
            string debugString = instance.GetDebugString();

            Assert.IsFalse(string.IsNullOrWhiteSpace(debugString));
        }

        private static Vehicle.Vehicle CreateDummyInstance() =>
            new Vehicle.Vehicle(
                DUMMY_YEAR, DUMMY_MAKE, DUMMY_MODEL, DUMMY_SERIAL,
                DUMMY_LENGTH, DUMMY_WIDTH, DUMMY_WEIGHT,
                new NoMotor(), new NoCabin(), new NoStorage());
    }
}