﻿using Discussion_Inheritance.Vehicle.Cabin;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class CabinTests
    {
        private const int DUMMY_SEATS = 5;
        private const int DUMMY_CUP_HOLDERS = 10;
        private const bool DUMMY_POWER_WINDOWS = true;
        private const bool DUMMY_POWER_LOCKS = true;
        private const SafetyFeatureType DUMMY_SAFETY_FEATURES = SafetyFeatureType.Airbags | SafetyFeatureType.Seatbelts;

        [Test]
        public static void Constructor_Sets_SeatCount()
        {
            Cabin instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_SEATS, instance.SeatCount);
        }

        [Test]
        public static void Constructor_Sets_CupHolderCount()
        {
            Cabin instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_CUP_HOLDERS, instance.CupHolderCount);
        }

        [Test]
        public static void Constructor_Sets_HasPowerWindows()
        {
            Cabin instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_POWER_WINDOWS, instance.HasPowerWindows);
        }

        [Test]
        public static void Constructor_Sets_HasPowerLocks()
        {
            Cabin instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_POWER_LOCKS, instance.HasPowerLocks);
        }

        [Test]
        public static void Constructor_Sets_SafetyFeatures()
        {
            Cabin instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_SAFETY_FEATURES, instance.SafetyFeatures);
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            Cabin instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static Cabin CreateDummyInstance() => new Cabin(
            DUMMY_SEATS, DUMMY_CUP_HOLDERS,
            DUMMY_POWER_WINDOWS, DUMMY_POWER_LOCKS,
            DUMMY_SAFETY_FEATURES);
    }
}