﻿using System.Numerics;
using Discussion_Inheritance.Vehicle.Storage;
using NUnit.Framework;

namespace Discussion_Inheritance.Tests
{
    [TestFixture]
    public static class InternalStorageTests
    {
        private const float DUMMY_TONNAGE = 1000f;
        private static readonly Vector3 DUMMY_DIMENSIONS = new Vector3(100, 100, 100);
        
        [Test]
        public static void Constructor_Sets_MaxTonnage()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_TONNAGE, instance.MaxTonnage);
        }

        [Test]
        public static void Constructor_Sets_InteriorDimensions()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.AreEqual(DUMMY_DIMENSIONS, instance.InteriorDimensionsFeet);
        }

        [Test]
        public static void Constructor_Sets_ExposedToElements_To_False()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.ExposedToElements);
        }

        [Test]
        public static void CanFitCargo_Returns_False_If_Tonnage_Exceeded()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.CanFitCargo(Vector3.Zero, DUMMY_TONNAGE + 1f));
        }

        [Test]
        public static void CanFitCargo_Returns_False_If_Dimensions_Exceeded()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(instance.CanFitCargo(new Vector3(DUMMY_DIMENSIONS.X + 1, DUMMY_DIMENSIONS.Y, DUMMY_DIMENSIONS.Z), 0f));
            Assert.IsFalse(instance.CanFitCargo(new Vector3(DUMMY_DIMENSIONS.X, DUMMY_DIMENSIONS.Y + 1, DUMMY_DIMENSIONS.Z), 0f));
            Assert.IsFalse(instance.CanFitCargo(new Vector3(DUMMY_DIMENSIONS.X, DUMMY_DIMENSIONS.Y, DUMMY_DIMENSIONS.Z + 1), 0f));
        }
        
        [Test]
        public static void CanFitCargo_Returns_True_If_Tonnage_Within_Bounds()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.CanFitCargo(Vector3.Zero, DUMMY_TONNAGE - 1f));
        }

        [Test]
        public static void CanFitCargo_Returns_True_If_Dimensions_Within_Bounds()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsTrue(instance.CanFitCargo(DUMMY_DIMENSIONS * 0.99f, 0f));
            Assert.IsTrue(instance.CanFitCargo(DUMMY_DIMENSIONS * 0.5f, 0f));
            Assert.IsTrue(instance.CanFitCargo(Vector3.Zero, 0f));
        }

        [Test]
        public static void GetDebugString_Is_Not_Null_Or_WhiteSpace()
        {
            InternalStorage instance = CreateDummyInstance();

            Assert.IsFalse(string.IsNullOrWhiteSpace(instance.GetDebugString()));
        }

        private static InternalStorage CreateDummyInstance() => new InternalStorage(DUMMY_TONNAGE, DUMMY_DIMENSIONS);
    }
}