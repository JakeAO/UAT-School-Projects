﻿using System;
using System.Numerics;
using Discussion_Inheritance.Vehicle;
using Discussion_Inheritance.Vehicle.Cabin;
using Discussion_Inheritance.Vehicle.Motor;
using Discussion_Inheritance.Vehicle.Storage;

namespace Discussion_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Vehicle selection options.
            // [0] 2012 Maxda RX-8, one of the rare passenger vehicles with a rotary engine.
            // [1] 2018 Chevy Bolt EV, and electric hatchback.
            // [2] 2018 Ford F-150, one of the most popular pickup trucks on the market.
            IVehicle[] vehicles =
            {
                new Vehicle.Vehicle(
                    2012, "Mazda", "RX-8", "1234-MZDA-RX8",
                    176f / 12f, 69.7f / 12f, 3051f,
                    new RotaryMotor(2, 3,
                        "1.3 L RENESIS", 137f,
                        speedMph => 0.3f,
                        FuelType.Gasoline, 8f, 0.1f),
                    new Cabin(4, 2, true, true, SafetyFeatureType.Seatbelts | SafetyFeatureType.Airbags),
                    new InternalStorage(0.2f, new Vector3(3f, 2f, 2f))),
                new Vehicle.Vehicle(
                    2018, "Chevy", "Bolt EV", "1234-CHEV-BEV",
                    164f / 12f, 69.5f / 12f, 3580f,
                    new ElectricMotor(
                        "GM BEV2", 91f,
                        speedMph => 1f,
                        60f, 2f),
                    new Cabin(5, 7, true, true, SafetyFeatureType.Seatbelts | SafetyFeatureType.Airbags | SafetyFeatureType.SideAirbags),
                    new InternalStorage(0.4f, new Vector3(3f, 2.5f, 3f))),
                new Vehicle.Vehicle(
                    2018, "Ford", "F-150", "1234-FORD-150",
                    209.3f / 12f, 79.9f / 12f, 5684f,
                    new ReciprocatingMotor(6,
                        "3.3 L TI-VCT V6 FFV", 100,
                        speedMph => 0.9f,
                        FuelType.Gasoline, 26f, 3f),
                    new Cabin(2, 2, true, true, SafetyFeatureType.Seatbelts | SafetyFeatureType.Airbags | SafetyFeatureType.SideAirbags),
                    new ExternalStorage(3270f / 2000f, new Vector3(65.2f / 12f, 3f, 67.1f / 12f), new Vector3(0f, 2f, 0f)))
            };

            // Draw debug text detailing each vehicles settings for the user.
            foreach (IVehicle vehicle in vehicles)
            {
                Console.WriteLine(vehicle.GetDebugString());
            }

            // Prompt the user to select a vehicle from the list above.
            // Repeat this prompt until the user selects a valid option from the provided list.
            int vehicleIdx = -1;
            do
            {
                Console.WriteLine("==========================================");
                Console.WriteLine("Select a Vehicle (Details Above)");
                for (int i = 0; i < vehicles.Length; i++)
                    Console.WriteLine($"   [{i}] {vehicles[i].GetIdentifier()}");
                string inputText = Console.ReadLine();
                int.TryParse(inputText, out vehicleIdx);

            } while (vehicleIdx < 0 || vehicleIdx >= vehicles.Length);

            // Store and confirm the user's vehicle selection.
            IVehicle selectedVehicle = vehicles[vehicleIdx];
            IMotor selectedMotor = selectedVehicle.Motor;

            Console.WriteLine("==========================================");
            Console.WriteLine($"\"{selectedVehicle.GetIdentifier()}\" Successfully Selected");

            // Display the current vehicle status and prompt the user to perform an action.
            // Repeat this prompt until the user decides to exit with the 'X' key.
            char inputOption = (char) 0;
            do
            {
                // Display Vehicle status and options to the user.
                Console.WriteLine("== Vehicle Status ==");
                Console.WriteLine($" Engine is {(selectedMotor.IsRunning ? "Running" : "Off")}. Remaining Fuel: {selectedMotor.CurrentFuelUnits} / {selectedMotor.MaximumFuelUnits}");
                Console.WriteLine($" Current Speed: {selectedMotor.CurrentSpeedMph}mph (Max: {selectedMotor.MaximumSpeedMph}mph)");
                Console.WriteLine("Select an Operation");
                Console.WriteLine($"   [S] {(selectedMotor.IsRunning ? "Stop" : "Start")} the Motor");
                Console.WriteLine("   [A] Accelerate");
                Console.WriteLine("   [D] Decelerate");
                Console.WriteLine("   [F] Add Fuel");
                Console.WriteLine("   [X] Exit Simulation");

                // Prompt for operation and repeat until a valid operation is chosen.
                // Perform the selected operation and track the success of the action.
                bool? operationSuccess = null;
                do
                {
                    string lineInput = Console.ReadLine();
                    inputOption = lineInput?.Length > 0 ? lineInput[0] : (char) 0;
                    switch (inputOption)
                    {
                        case 's' when selectedMotor.IsRunning:
                        case 'S' when selectedMotor.IsRunning:
                            operationSuccess = selectedMotor.Stop();
                            break;
                        case 's' when !selectedMotor.IsRunning:
                        case 'S' when !selectedMotor.IsRunning:
                            operationSuccess = selectedMotor.Start();
                            break;
                        case 'a':
                        case 'A':
                            operationSuccess = selectedMotor.TryAccelerate();
                            break;
                        case 'd':
                        case 'D':
                            operationSuccess = selectedMotor.TryDecelerate();
                            break;
                        case 'f':
                        case 'F':
                            float fuelAmount = selectedMotor.MaximumFuelUnits * 0.2f;
                            operationSuccess = selectedMotor.TryFuel(selectedMotor.FuelType, ref fuelAmount);
                            break;
                        case 'x':
                        case 'X':
                            operationSuccess = true;
                            break;
                    }
                } while (operationSuccess == null);

                // Log operation success to the user.
                Console.WriteLine(operationSuccess.Value ? "++ Operation Successful ++" : "!! Operation Failed !!");
            } while (inputOption != 'x' && inputOption != 'X');

            // That's all, folks.
            Console.WriteLine("Goodbye!");
        }
    }
}