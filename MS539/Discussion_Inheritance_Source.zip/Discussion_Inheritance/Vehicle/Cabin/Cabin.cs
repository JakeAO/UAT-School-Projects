﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Discussion_Inheritance.Vehicle.Cabin
{
    /// <summary>
    /// Standard Cabin object type to hold information pertaining to the passenger compartment of a vehicle.
    /// </summary>
    public class Cabin : ICabin
    {
        public uint SeatCount { get; }
        public uint CupHolderCount { get; }
        public bool HasPowerWindows { get; }
        public bool HasPowerLocks { get; }
        public SafetyFeatureType SafetyFeatures { get; }

        public Cabin(
            uint seatCount, uint cupHolderCount,
            bool hasPowerWindows, bool hasPowerLocks,
            SafetyFeatureType safetyFeatures)
        {
            SeatCount = seatCount;
            CupHolderCount = cupHolderCount;
            HasPowerWindows = hasPowerWindows;
            HasPowerLocks = hasPowerLocks;
            SafetyFeatures = safetyFeatures;
        }

        public string GetDebugString()
        {
            HashSet<string> featureSet = new HashSet<string>();
            if (HasPowerWindows)
                featureSet.Add("Power Windows");
            if (HasPowerLocks)
                featureSet.Add("Power Locks");
            foreach (int safetyFeatureValue in Enum.GetValues(typeof(SafetyFeatureType)))
            {
                if (((int) SafetyFeatures & safetyFeatureValue) == safetyFeatureValue)
                    featureSet.Add(((SafetyFeatureType) safetyFeatureValue).ToString());
            }
            
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<Cabin>");
            sb.AppendLine($"  Passenger Capacity: {SeatCount} (w/ {CupHolderCount} cupholders!)");
            sb.AppendLine($"  Features: {string.Join(", ", featureSet)}");
            sb.AppendLine("</Cabin>");
            return sb.ToString();
        }
    }
}