﻿namespace Discussion_Inheritance.Vehicle.Cabin
{
    public interface ICabin
    {
        /// <summary>
        /// The number of seats in the cabin, including driver and passenger(s).
        /// </summary>
        uint SeatCount { get; }
        
        /// <summary>
        /// The number of standard-sized cup-holders in the cabin.
        /// </summary>
        uint CupHolderCount { get; }

        /// <summary>
        /// Does the cabin feature power windows?
        /// </summary>
        bool HasPowerWindows { get; }
        
        /// <summary>
        /// Does the cabin feature power door locks, either electric, vacuum, or otherwise.
        /// </summary>
        bool HasPowerLocks { get; }
        
        /// <summary>
        /// Bitmask of the standard safety features this cabin offers.
        /// </summary>
        SafetyFeatureType SafetyFeatures { get; }

        /// <summary>
        /// Create a formatted string for console debugging.
        /// </summary>
        /// <returns>Formatted debug string.</returns>
        string GetDebugString();
    }
}