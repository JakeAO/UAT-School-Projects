﻿namespace Discussion_Inheritance.Vehicle.Cabin
{
    /// <summary>
    /// Dummy Cabin object type for mocking and tests.
    /// </summary>
    public class NoCabin : ICabin
    {
        public uint SeatCount => 0u;
        public uint CupHolderCount => 0u;
        public bool HasPowerWindows => false;
        public bool HasPowerLocks => false;
        public SafetyFeatureType SafetyFeatures => SafetyFeatureType.Invalid;

        public string GetDebugString() => "<Cabin: NONE/>";
    }
}