﻿using System;

namespace Discussion_Inheritance.Vehicle.Cabin
{
    [Flags]
    public enum SafetyFeatureType : int
    {
        Invalid = 0,
        Seatbelts = 1,
        Airbags = 2,
        SideAirbags = 4,
    }
}