﻿namespace Discussion_Inheritance.Vehicle.Motor
{
    public enum FuelType
    {
        Invalid = 0,
        Gasoline = 1,
        Diesel = 2,
        CompressedNaturalGas = 4,
        Electricity = 8,
    }
}