﻿using System;

namespace Discussion_Inheritance.Vehicle.Motor
{
    /// <summary>
    /// Object type for a standard ICE engine that burns fuel to operate.
    /// </summary>
    public class ReciprocatingMotor : MotorBase
    {
        public uint CylinderCount { get; }

        public ReciprocatingMotor(
            uint cylinderCount,
            string motorName, float maximumSpeedMph,
            Func<float, float> fuelConsumptionAtSpeed,
            FuelType fuelType, float maximumFuelUnits, float minimumFuelUnits)
            : base(motorName, maximumSpeedMph, fuelConsumptionAtSpeed, fuelType, maximumFuelUnits, minimumFuelUnits)
        {
            CylinderCount = cylinderCount;
        }

        public override bool TryAccelerate()
        {
            if (!IsRunning)
                return false;
            if (CurrentSpeedMph >= MaximumSpeedMph)
                return false;
            if (CurrentFuelUnits <= MinimumFuelUnits)
                return false;
            if (!TryIncreaseRpm())
                return false;
            
            CurrentFuelUnits = Math.Max(CurrentFuelUnits - FuelConsumptionAtSpeed(CurrentSpeedMph), 0f);
            CurrentSpeedMph = Math.Min(CurrentSpeedMph + 1, MaximumSpeedMph);
            return true;
        }

        public override bool TryDecelerate()
        {
            if (CurrentSpeedMph <= 0f)
                return false;

            CurrentSpeedMph = Math.Max(CurrentSpeedMph - 2, 0f);
            return true;
        }

        private bool TryIncreaseRpm()
        {
            // Do ICE rpm increase.
            // - Inject fuel.
            // - Fire cylinders in the right order.
            // - etc.

            return true;
        }
    }
}