﻿using System;

namespace Discussion_Inheritance.Vehicle.Motor
{
    /// <summary>
    /// Dummy Motor object type for mocks and tests.
    /// </summary>
    public class NoMotor : IMotor
    {
        public string Name => "NoMotor";
        public float MaximumSpeedMph => 0f;
        public float CurrentSpeedMph => 0f;
        public Func<float, float> FuelConsumptionAtSpeed => null;
        public FuelType FuelType => FuelType.Invalid;
        public float CurrentFuelUnits => 0f;
        public float MaximumFuelUnits => 0f;
        public float MinimumFuelUnits => 0f;
        public bool IsRunning => false;

        public bool Start() { return false; }
        public bool Stop() { return false; }

        public bool TryAccelerate() { return false; }
        public bool TryDecelerate() { return false; }

        public bool TryFuel(FuelType fuelType, ref float fuelAmount) { return false; }

        public string GetDebugString() => "<Motor: NONE/>";
    }
}