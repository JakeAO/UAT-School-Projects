﻿using System;
using System.Diagnostics;
using System.Text;

namespace Discussion_Inheritance.Vehicle.Motor
{
    public abstract class MotorBase : IMotor
    {
        public string Name { get; }
        
        public float MaximumSpeedMph { get; }
        public float CurrentSpeedMph { get; protected set; }
        
        public Func<float, float> FuelConsumptionAtSpeed { get; }

        public FuelType FuelType { get; }
        public float CurrentFuelUnits { get; protected set; }
        public float MaximumFuelUnits { get; }
        public float MinimumFuelUnits { get; }

        public bool IsRunning { get; protected set; }

        protected MotorBase(
            string motorName, float maximumSpeedMph,
            Func<float, float> fuelConsumptionAtSpeed,
            FuelType fuelType, float maximumFuelUnits, float minimumFuelUnits)
        {
            Debug.Assert(fuelConsumptionAtSpeed != null);
            Debug.Assert(minimumFuelUnits < maximumFuelUnits);

            Name = motorName;
            
            MaximumSpeedMph = maximumSpeedMph;
            CurrentSpeedMph = 0;

            FuelConsumptionAtSpeed = fuelConsumptionAtSpeed;

            FuelType = fuelType;
            MaximumFuelUnits = maximumFuelUnits;
            MinimumFuelUnits = minimumFuelUnits;
        }

        public bool Start()
        {
            if (IsRunning)
                return false;

            if (CurrentFuelUnits < MinimumFuelUnits)
                return false;

            IsRunning = true;
            return true;
        }

        public bool Stop()
        {
            if (!IsRunning)
                return false;

            if (CurrentSpeedMph > 0f)
                return false;

            IsRunning = false;
            return true;
        }

        public abstract bool TryAccelerate();

        public abstract bool TryDecelerate();

        public bool TryFuel(FuelType fuelType, ref float fuelAmount)
        {
            if (FuelType != fuelType)
                return false;

            float fillAmount = Math.Min(MaximumFuelUnits - CurrentFuelUnits, fuelAmount);
            if (fillAmount <= 0f)
                return false;
            
            CurrentFuelUnits += fillAmount;
            fuelAmount -= fillAmount;

            return true;
        }

        public virtual string GetDebugString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"<Motor: {Name}>");
            sb.AppendLine($"  Fuel: {FuelType} {CurrentFuelUnits}/{MaximumFuelUnits} ({(CurrentFuelUnits / MaximumFuelUnits):P2})");
            sb.AppendLine($"  Running: {IsRunning}");
            
            if (IsRunning)
            {
                sb.AppendLine($"  Speed: {CurrentSpeedMph}mph ({MaximumSpeedMph} max mph)");
                sb.AppendLine($"  Consumption: {FuelConsumptionAtSpeed(CurrentSpeedMph)}");
            }

            sb.AppendLine("</Motor>");
            return sb.ToString();
        }
    }
}