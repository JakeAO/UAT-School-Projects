﻿using System;

namespace Discussion_Inheritance.Vehicle.Motor
{
    /// <summary>
    /// Object type for Rotary engines that behave distinctly differently than their other ICE brethren.
    /// </summary>
    public class RotaryMotor : MotorBase
    {
        public uint RotorCount { get; }
        public uint CylindersPerRotor { get; }

        public RotaryMotor(
            uint rotorCount, uint cylindersPerRotor,
            string motorName, float maximumSpeedMph,
            Func<float, float> fuelConsumptionAtSpeed,
            FuelType fuelType, float maximumFuelUnits, float minimumFuelUnits)
            : base(motorName, maximumSpeedMph, fuelConsumptionAtSpeed, fuelType, maximumFuelUnits, minimumFuelUnits)
        {
            RotorCount = rotorCount;
            CylindersPerRotor = cylindersPerRotor;
        }

        public override bool TryAccelerate()
        {
            if (!IsRunning)
                return false;
            if (CurrentSpeedMph >= MaximumSpeedMph)
                return false;
            if (CurrentFuelUnits <= MinimumFuelUnits)
                return false;
            if (!TryIncreaseRpm())
                return false;

            CurrentFuelUnits = Math.Max(CurrentFuelUnits - FuelConsumptionAtSpeed(CurrentSpeedMph), 0f);
            CurrentSpeedMph = Math.Min(CurrentSpeedMph + 2, MaximumSpeedMph);
            return true;
        }

        public override bool TryDecelerate()
        {
            if (CurrentSpeedMph <= 0f)
                return false;

            CurrentSpeedMph = Math.Max(CurrentSpeedMph - 2, 0f);
            return true;
        }

        private bool TryIncreaseRpm()
        {
            // Do Rotary RPM increase
            // - Inject fuel
            // - Fire appropriate cylinders

            return true;
        }
    }
}