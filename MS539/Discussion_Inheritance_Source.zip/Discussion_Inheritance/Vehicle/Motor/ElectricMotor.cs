﻿using System;

namespace Discussion_Inheritance.Vehicle.Motor
{
    /// <summary>
    /// Object type for EV motors that behave distinctly differently than ICE or other engine types.
    /// </summary>
    public class ElectricMotor : MotorBase
    {
        public ElectricMotor(
            string motorName, float maximumSpeedMph,
            Func<float, float> fuelConsumptionAtSpeed,
            float maximumFuelUnits, float minimumFuelUnits)
            : base(motorName, maximumSpeedMph, fuelConsumptionAtSpeed, FuelType.Electricity, maximumFuelUnits, minimumFuelUnits)
        {
        }

        public override bool TryAccelerate()
        {
            if (!IsRunning)
                return false;
            if (CurrentSpeedMph >= MaximumSpeedMph)
                return false;
            if (CurrentFuelUnits <= MinimumFuelUnits)
                return false;
            if (!TryIncreaseMotorVoltage())
                return false;

            CurrentFuelUnits = Math.Max(CurrentFuelUnits - FuelConsumptionAtSpeed(CurrentSpeedMph), 0f);
            CurrentSpeedMph = Math.Min(CurrentSpeedMph + 3, MaximumSpeedMph);
            return true;
        }

        public override bool TryDecelerate()
        {
            if (CurrentSpeedMph <= 0f)
                return false;

            float decelerationAmount = TryRegenerativeBreaking(out float multiplier) ? 2f * multiplier : 2f;
            CurrentSpeedMph = Math.Max(CurrentSpeedMph - decelerationAmount, 0f);
            return true;
        }

        private bool TryIncreaseMotorVoltage()
        {
            // Do EV motor stuff.

            return true;
        }

        private bool TryRegenerativeBreaking(out float decelerationMultiplier)
        {
            // Do EV regenerative engine breaking.

            decelerationMultiplier = 1f;
            if (CurrentFuelUnits < MaximumFuelUnits * 0.95f &&
                CurrentSpeedMph >= 10f)
            {
                decelerationMultiplier = 2f;
                CurrentFuelUnits = Math.Min(CurrentFuelUnits + 0.5f, MaximumFuelUnits);
                return true;
            }

            return false;
        }
    }
}