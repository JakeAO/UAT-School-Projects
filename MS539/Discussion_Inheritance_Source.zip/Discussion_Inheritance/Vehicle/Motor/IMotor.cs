﻿using System;

namespace Discussion_Inheritance.Vehicle.Motor
{
    public interface IMotor
    {
        /// <summary>
        /// Name of the engine.
        /// </summary>
        string Name { get; }
        
        /// <summary>
        /// Maximum speed in MPH that the motor's governor allows it to go.
        /// </summary>
        float MaximumSpeedMph { get; }
        
        /// <summary>
        /// Current speed in MPH of the motor.
        /// </summary>
        float CurrentSpeedMph { get; }
        
        /// <summary>
        /// Function that calculates the fuel unit consumption at a given speed in MPH.
        /// </summary>
        Func<float, float> FuelConsumptionAtSpeed { get; }

        /// <summary>
        /// Fuel type that is required for the motor to operate.
        /// </summary>
        FuelType FuelType { get; }
        
        /// <summary>
        /// Current fuel available for the motor's operation.
        /// </summary>
        float CurrentFuelUnits { get; }
        
        /// <summary>
        /// Maximum fuel capacity of the motor, this cannot be exceeded.
        /// </summary>
        float MaximumFuelUnits { get; }
        
        /// <summary>
        /// Minimum fuel content required for the motor to properly operate.
        /// </summary>
        float MinimumFuelUnits { get; }

        /// <summary>
        /// Is the motor currently running.
        /// </summary>
        bool IsRunning { get; }
        
        /// <summary>
        /// Attempt to start the motor.
        /// </summary>
        /// <returns>True if motor was successfully started.</returns>
        bool Start();

        /// <summary>
        /// Attempt to turn off the motor.
        /// </summary>
        /// <returns>True if the motor was successfully stopped.</returns>
        bool Stop();

        /// <summary>
        /// Attempt to accelerate.
        /// </summary>
        /// <returns>True if the MPH was increased.</returns>
        bool TryAccelerate();
        
        /// <summary>
        /// Attempt to brake.
        /// </summary>
        /// <returns>True if the MPH was decreased.</returns>
        bool TryDecelerate();

        /// <summary>
        /// Attempt to insert fuel into the motor. Will fail if the fuel type is incorrect. FuelAmount will be modified based on the fuel actually inserted.
        /// </summary>
        /// <param name="fuelType">Type of fuel to be inserted.</param>
        /// <param name="fuelAmount">Maximum amount of fuel to be inserted.</param>
        /// <returns>True if motor was successfully fueled.</returns>
        bool TryFuel(FuelType fuelType, ref float fuelAmount);

        /// <summary>
        /// Get a detailed debug string for logging.
        /// </summary>
        /// <returns>Detailed debug string.</returns>
        string GetDebugString();
    }
}