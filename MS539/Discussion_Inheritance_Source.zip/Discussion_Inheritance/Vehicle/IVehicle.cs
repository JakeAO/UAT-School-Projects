﻿using Discussion_Inheritance.Vehicle.Cabin;
using Discussion_Inheritance.Vehicle.Motor;
using Discussion_Inheritance.Vehicle.Storage;

namespace Discussion_Inheritance.Vehicle
{
    public interface IVehicle
    {
        /// <summary>
        /// The model year of the vehicle.
        /// </summary>
        uint Year { get; }
        
        /// <summary>
        /// The make or brand of the vehicle.
        /// </summary>
        string Make { get; }
        
        /// <summary>
        /// The model or series name of the vehicle.
        /// </summary>
        string Model { get; }
        
        /// <summary>
        /// The unique serial number of the vehicle.
        /// </summary>
        string Serial { get; }
        
        /// <summary>
        /// The vehicle's full length in feet.
        /// </summary>
        float LengthFeet { get; }
        
        /// <summary>
        /// The vehicle's full width in feet.
        /// </summary>
        float WidthFeet { get; }
        
        /// <summary>
        /// The vehicle's curb weight (no passengers or cargo) in pounds.
        /// </summary>
        float CurbWeightPounds { get; }
        
        /// <summary>
        /// The motor object that powers this vehicle.
        /// </summary>
        IMotor Motor { get; }
        
        /// <summary>
        /// The passenger cabin object of this vehicle.
        /// </summary>
        ICabin Cabin { get; }
        
        /// <summary>
        /// The storage object of this vehicle.
        /// </summary>
        IStorage Storage { get; }

        /// <summary>
        /// Get the vehicle's full unique identifier.
        /// </summary>
        /// <returns>Unique identifier of this specific vehicle.</returns>
        string GetIdentifier();

        /// <summary>
        /// Get a debug string containing detailed object information w/o overriding the default ToString().
        /// </summary>
        /// <returns>A debug string with object details.</returns>
        string GetDebugString();
    }
}