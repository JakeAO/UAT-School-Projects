﻿using System.Numerics;

namespace Discussion_Inheritance.Vehicle.Storage
{
    /// <summary>
    /// Interface for a vehicle's storage capabilities,
    /// specifically the trunk, bed, or other rear storage of the vehicle.
    /// </summary>
    public interface IStorage
    {
        /// <summary>
        /// Maximum allowable cargo tonnage that the storage can safely support.
        /// </summary>
        float MaxTonnage { get; }
        
        /// <summary>
        /// Maximum cargo capacity in feet that the storage can safely support.
        /// </summary>
        Vector3 InteriorDimensionsFeet { get; }
        
        /// <summary>
        /// Is this storage exposed to rain/snow/wind or is it safely contained.
        /// </summary>
        bool ExposedToElements { get; }

        /// <summary>
        /// Can the provided cargo specifications safely fit inside of the storage.
        /// </summary>
        /// <param name="objectDimensionsFeet">Cargo dimensions in feet.</param>
        /// <param name="objectWeightTons">Cargo weight in tons.</param>
        /// <returns>True if the provided cargo specifications will fit.</returns>
        bool CanFitCargo(Vector3 objectDimensionsFeet, float objectWeightTons);
        
        string GetDebugString();
    }
}