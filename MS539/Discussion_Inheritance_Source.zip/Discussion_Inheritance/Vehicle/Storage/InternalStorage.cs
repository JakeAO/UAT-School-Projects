﻿using System.Numerics;

namespace Discussion_Inheritance.Vehicle.Storage
{
    /// <summary>
    /// Interior storage for the likes of a sedan's trunk or the SUV's rear compartment.
    /// </summary>
    public class InternalStorage : StorageBase
    {
        public InternalStorage(float maxTonnage, Vector3 interiorDimensions)
            : base(maxTonnage, interiorDimensions, false)
        {
        }
    }
}