﻿using System.Numerics;

namespace Discussion_Inheritance.Vehicle.Storage
{
    /// <summary>
    /// Exterior storage such as that of a standard or flat-bed truck,
    /// allowing for the common practice of exceeding the defined dimensions with cargo.
    /// </summary>
    public class ExternalStorage : StorageBase
    {
        /// <summary>
        /// Additional cargo dimensions that are supported by the storage due to it's exposed nature.
        /// Is added onto the InteriorDimensionsFeet when checking if cargo will fit.
        /// </summary>
        public Vector3 AllowedOverflowFeet { get; }

        public ExternalStorage(float maxTonnage, Vector3 interiorDimensions, Vector3 allowedOverflowFeet)
            : base(maxTonnage, interiorDimensions, true)
        {
            AllowedOverflowFeet = allowedOverflowFeet;
        }

        public override bool CanFitCargo(Vector3 objectDimensionsFeet, float weightTons)
        {
            return objectDimensionsFeet.X < InteriorDimensionsFeet.X + AllowedOverflowFeet.X &&
                   objectDimensionsFeet.Y < InteriorDimensionsFeet.Y + AllowedOverflowFeet.Y &&
                   objectDimensionsFeet.Z < InteriorDimensionsFeet.Z + AllowedOverflowFeet.Z &&
                   weightTons < MaxTonnage;
        }
    }
}