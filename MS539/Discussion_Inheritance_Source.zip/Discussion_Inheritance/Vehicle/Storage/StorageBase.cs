﻿using System.Numerics;
using System.Text;

namespace Discussion_Inheritance.Vehicle.Storage
{
    /// <summary>
    /// Base storage class for a vehicles storage capabilities, if it has any.
    /// </summary>
    public abstract class StorageBase : IStorage
    {
        public float MaxTonnage { get; }
        public Vector3 InteriorDimensionsFeet { get; }
        public bool ExposedToElements { get; }

        protected StorageBase(float maxTonnage, Vector3 interiorDimensions, bool exposedToElements)
        {
            MaxTonnage = maxTonnage;
            InteriorDimensionsFeet = interiorDimensions;
            ExposedToElements = exposedToElements;
        }

        public virtual bool CanFitCargo(Vector3 objectDimensionsFeet, float weightTons)
        {
            return objectDimensionsFeet.X < InteriorDimensionsFeet.X &&
                   objectDimensionsFeet.Y < InteriorDimensionsFeet.Y &&
                   objectDimensionsFeet.Z < InteriorDimensionsFeet.Z &&
                   weightTons < MaxTonnage;
        }

        public virtual string GetDebugString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<Storage>");
            sb.AppendLine($"  Max Tonnage: {MaxTonnage} tonnes");
            sb.AppendLine($"  Max Dimensions: {InteriorDimensionsFeet.X}ft x {InteriorDimensionsFeet.Y}ft x {InteriorDimensionsFeet.Z}ft");
            sb.AppendLine($"  Exposed: {ExposedToElements}");
            sb.AppendLine("</Storage>");
            return sb.ToString();
        }
    }
}