﻿using System.Numerics;

namespace Discussion_Inheritance.Vehicle.Storage
{
    /// <summary>
    /// Certain varieties of vehicle have no discrete storage section,
    /// such as sports cars, roadsters, and certain coupes.
    /// </summary>
    public class NoStorage : IStorage
    {
        public float MaxTonnage => 0f;
        public Vector3 InteriorDimensionsFeet => Vector3.Zero;
        public bool ExposedToElements => false;

        public bool CanFitCargo(Vector3 objectDimensionsFeet, float objectWeightTons) => false;

        public virtual string GetDebugString() => "<Storage: NONE />";
    }
}