﻿using System.Diagnostics;
using System.Text;
using Discussion_Inheritance.Vehicle.Cabin;
using Discussion_Inheritance.Vehicle.Motor;
using Discussion_Inheritance.Vehicle.Storage;

namespace Discussion_Inheritance.Vehicle
{
    public class Vehicle : IVehicle
    {
        public uint Year { get; }
        public string Make { get; }
        public string Model { get; }
        public string Serial { get; }
        public float LengthFeet { get; }
        public float WidthFeet { get; }
        public float CurbWeightPounds { get; }
        
        public IMotor Motor { get; }
        public ICabin Cabin { get; }
        public IStorage Storage { get; }

        public Vehicle(
            uint year, string make, string model, string serial,
            float length, float width, float weight,
            IMotor motor, ICabin cabin, IStorage storage)
        {
            Debug.Assert(motor != null);
            Debug.Assert(cabin != null);
            Debug.Assert(storage != null);

            Year = year;
            Make = make;
            Model = model;
            Serial = serial;
            LengthFeet = length;
            WidthFeet = width;
            CurbWeightPounds = weight;
            Motor = motor;
            Cabin = cabin;
            Storage = storage;
        }

        public string GetIdentifier()
        {
            return $"{Year} {Make} {Model} ({Serial})";
        }

        public string GetDebugString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"<Vehicle: {GetIdentifier()}>");
            sb.AppendLine($"  Dimensions: {LengthFeet}ft x {WidthFeet}ft");
            sb.AppendLine($"  Curb Weight: {CurbWeightPounds}lbs");
            sb.Append(Motor.GetDebugString());
            sb.Append(Cabin.GetDebugString());
            sb.Append(Storage.GetDebugString());
            sb.AppendLine("</Vehicle>");
            return sb.ToString();
        }
    }
}