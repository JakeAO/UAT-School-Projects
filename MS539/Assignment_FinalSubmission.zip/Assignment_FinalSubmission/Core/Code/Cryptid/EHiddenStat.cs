﻿namespace Core.Code.Cryptid
{
    public enum EHiddenStat
    {
        Morale = 0,
        Lifespan = 1,
        HealthMultiplier = 2,

        _Count
    }
}