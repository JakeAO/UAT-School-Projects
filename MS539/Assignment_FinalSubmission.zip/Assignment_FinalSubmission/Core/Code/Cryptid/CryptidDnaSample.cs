﻿namespace Core.Code.Cryptid
{
    public class CryptidDnaSample
    {
        public Cryptid Cryptid;

        public CryptidDnaSample(Cryptid cryptid)
        {
            Cryptid = cryptid;
        }
    }
}