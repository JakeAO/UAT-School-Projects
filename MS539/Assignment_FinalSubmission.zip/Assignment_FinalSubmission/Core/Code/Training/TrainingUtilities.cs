﻿namespace Core.Code.Training
{
    public class TrainingUtilities
    {
    }
}