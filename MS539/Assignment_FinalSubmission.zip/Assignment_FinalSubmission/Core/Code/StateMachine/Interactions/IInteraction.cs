﻿namespace Core.Code.StateMachine.Interactions
{
    public interface IInteraction
    {
    }
}