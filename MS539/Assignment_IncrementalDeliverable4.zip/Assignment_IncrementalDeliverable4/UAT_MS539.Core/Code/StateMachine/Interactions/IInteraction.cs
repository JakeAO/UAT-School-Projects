﻿namespace UAT_MS539.Core.Code.StateMachine.Interactions
{
    public interface IInteraction
    {
    }
}