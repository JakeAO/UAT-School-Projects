﻿using System;
using System.Collections.Generic;
using System.Linq;
using UAT_MS539.Core.Code.Cryptid;
using UAT_MS539.Core.Code.Food;
using UAT_MS539.Core.Code.Training;
using UAT_MS539.Core.Code.Utility;

namespace UAT_MS539.Code
{
    public static class TooltipUtil
    {
        public static List<string> GetTooltipContent(Food food, LocDatabase locDatabase)
        {
            List<string> tooltipContent = new List<string>(5);
            if (food.MoraleBoost > 0)
            {
                tooltipContent.Add($"{locDatabase.Localize(EHiddenStat.Morale)} +{food.MoraleBoost}");
            }
            if (food.BoostsByStat.Values.Any(x => x > 0))
            {
                tooltipContent.Add(locDatabase.Localize("Tooltip/TrainingBonus"));
                foreach (var boostKvp in food.BoostsByStat)
                {
                    if (boostKvp.Value > 0)
                    {
                        tooltipContent.Add($"  {locDatabase.Localize(boostKvp.Key)} xp +{boostKvp.Value}");
                    }
                }
            }
            if (food.MultipliersByStat.Values.Any(x => Math.Abs(x - 1f) > 0.01f))
            {
                tooltipContent.Add(locDatabase.Localize("Tooltip/TrainingMultiplier"));
                foreach (var multKvp in food.MultipliersByStat)
                {
                    if (Math.Abs(multKvp.Value - 1f) > 0.01f)
                    {
                        tooltipContent.Add($"  {locDatabase.Localize(multKvp.Key)} xp x{multKvp.Value}");
                    }
                }
            }
            if (tooltipContent.Count == 0)
            {
                tooltipContent.Add(locDatabase.Localize("Tooltip/TrainingNoBonus"));
            }
            return tooltipContent;
        }

        public static List<string> GetTooltipContent(CryptidDnaSample dnaSample, LocDatabase locDatabase)
        {
            List<string> tooltipContent = new List<string>(15);
            tooltipContent.Add($"{locDatabase.Localize(dnaSample.Cryptid.Species.NameId)} ({locDatabase.Localize(dnaSample.Cryptid.Color.NameId)})");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Health)}: {dnaSample.Cryptid.SecondaryStats[(int)ESecondaryStat.Health]}");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Stamina)}: {dnaSample.Cryptid.SecondaryStats[(int)ESecondaryStat.Stamina]}");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Renown)}: {dnaSample.Cryptid.SecondaryStats[(int)ESecondaryStat.Renown]}");
            for (int i = 0; i < (int)EPrimaryStat._Count; i++)
                tooltipContent.Add($"{locDatabase.Localize((EPrimaryStat)i)}: {dnaSample.Cryptid.PrimaryStats[i]}");
            return tooltipContent;
        }

        public static List<string> GetTooltipContent(Cryptid cryptid, LocDatabase locDatabase)
        {
            List<string> tooltipContent = new List<string>(15);
            tooltipContent.Add($"{locDatabase.Localize(cryptid.Species.NameId)} ({locDatabase.Localize(cryptid.Color.NameId)})");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Health)}: {cryptid.SecondaryStats[(int)ESecondaryStat.Health]}");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Stamina)}: {cryptid.SecondaryStats[(int)ESecondaryStat.Stamina]}");
            tooltipContent.Add($"{locDatabase.Localize(ESecondaryStat.Renown)}: {cryptid.SecondaryStats[(int)ESecondaryStat.Renown]}");
            tooltipContent.Add($"{locDatabase.Localize("Stat/Age")}: {cryptid.AgeInDays}");
            for (int i = 0; i < (int)EPrimaryStat._Count; i++)
                tooltipContent.Add($"{locDatabase.Localize((EPrimaryStat)i)}: {cryptid.PrimaryStats[i]}");
            return tooltipContent;
        }

        public static List<string> GetTooltipContent(TrainingRegimen trainingRegimen, LocDatabase locDatabase)
        {
            List<string> tooltipContent = new List<string>(6);
            for (int i = 0; i < (int)EPrimaryStat._Count; i++)
            {
                EPrimaryStat enumVal = (EPrimaryStat)i;
                uint minGain = 0, maxGain = 0;

                if (trainingRegimen.GuaranteedStatIncrease.TryGetValue(enumVal, out uint guaranteedValue))
                {
                    minGain = maxGain = guaranteedValue;
                }
                if (trainingRegimen.RandomStatIncreases.TryGetValue(enumVal, out var randomDropCalculation))
                {
                    minGain += randomDropCalculation.Points.Min(x => x.Value);
                    maxGain += randomDropCalculation.Points.Max(x => x.Value);
                }

                if (minGain != maxGain)
                {
                    tooltipContent.Add($"{locDatabase.Localize(enumVal)} xp +{minGain}-{maxGain}");
                }
                else if (minGain > 0)
                {
                    tooltipContent.Add($"{locDatabase.Localize(enumVal)} xp +{minGain}");
                }
            }
            return tooltipContent;
        }
    }
}
