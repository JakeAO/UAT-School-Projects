﻿namespace UAT_MS539.ConsoleApp
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            new MainClass();
        }
    }
}