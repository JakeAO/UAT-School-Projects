﻿using System.Windows;

namespace UAT_MS539
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}