﻿namespace UAT_MS539.Core.Code.Cryptid
{
    public enum EPrimaryStat
    {
        Strength = 0,
        Speed = 1,
        Vitality = 2,
        Smarts = 3,
        Skill = 4,
        Luck = 5,

        _Count
    }
}