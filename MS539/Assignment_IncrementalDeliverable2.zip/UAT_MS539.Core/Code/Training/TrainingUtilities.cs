﻿namespace UAT_MS539.Core.Code.Training
{
    public class TrainingUtilities
    {
    }
}