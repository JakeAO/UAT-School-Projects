﻿namespace UAT_MS539.Core.Code.Cryptid
{
    public enum ESecondaryStat
    {
        Health = 0,
        Renown = 1,
        Stamina = 2,

        _Count
    }
}