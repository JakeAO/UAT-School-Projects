var searchData=
[
  ['description_220',['Description',['../class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators_1_1_no_cost.html#adfb60530945b49f3d858702a06c2ead5',1,'SadPumpkin.Util.CombatEngine.CostCalculators.NoCost.Description()'],['../class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect.html#a83008f22576ab69c3b2ff3b1e79d74ac',1,'SadPumpkin.Util.CombatEngine.EffectCalculators.NoEffect.Description()'],['../class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_requirement_calculators_1_1_no_requirements.html#a72bc5a9b5dd335654f68b81ff27b3725',1,'SadPumpkin.Util.CombatEngine.RequirementCalculators.NoRequirements.Description()']]]
];
