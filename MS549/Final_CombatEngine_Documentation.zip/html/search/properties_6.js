var searchData=
[
  ['name_241',['Name',['../interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#aaf14004134d82f7c28b877fb510cb289',1,'SadPumpkin::Util::CombatEngine::Actor::IInitiativeActor']]]
];
