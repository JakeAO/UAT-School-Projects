var searchData=
[
  ['nextid_222',['NextId',['../class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#a579eaaec593b8a4ec1a888c188bb3dac',1,'SadPumpkin::Util::CombatEngine::GameState::GameState']]]
];
