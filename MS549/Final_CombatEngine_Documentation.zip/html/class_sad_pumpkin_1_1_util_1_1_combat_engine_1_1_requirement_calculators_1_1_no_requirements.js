var class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_requirement_calculators_1_1_no_requirements =
[
    [ "MeetsRequirement", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_requirement_calculators_1_1_no_requirements.html#a87b8c8d032b79ff80dc33b30b9015856", null ],
    [ "Description", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_requirement_calculators_1_1_no_requirements.html#a72bc5a9b5dd335654f68b81ff27b3725", null ]
];