var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_i_target_calc =
[
    [ "CanTarget", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_i_target_calc.html#acd15add51f3f4f663e75ede865df40ce", null ],
    [ "GetTargetOptions", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_i_target_calc.html#aedad939e4cdaeeac78a3f1e77b79ea86", null ],
    [ "Description", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_i_target_calc.html#aa01550484ee35cdb6aa56cf5e7541024", null ]
];