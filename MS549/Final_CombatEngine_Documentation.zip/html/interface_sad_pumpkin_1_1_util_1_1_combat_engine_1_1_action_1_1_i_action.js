var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action =
[
    [ "ActionProvider", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#aecac16e06b38bc97fece914e6e8e3322", null ],
    [ "ActionSource", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#ab6e7825aad2beed58ae3204ee36c9c15", null ],
    [ "Available", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#a8023897d9ac6554552e35a3ca90ee68a", null ],
    [ "Cost", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#a731422f4af3ab1cfabde107b2dbac50a", null ],
    [ "Effect", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#ae36e245cf3b8e0eba89cd2b2fe0b3362", null ],
    [ "Id", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#ae37451a3ffe4f6ba66a973f870af283c", null ],
    [ "Source", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#a0e555ac86d52d0d8631e6a41a78ebac9", null ],
    [ "Speed", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#a1571d5ef0c9a7f7fc49c5381e990ed06", null ],
    [ "Targets", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_action_1_1_i_action.html#ab4e7dfaf4b609d948d6b1f25da4c2cfe", null ]
];