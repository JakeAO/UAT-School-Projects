var dir_a71c3b2ad23b9ff58220dd012d201987 =
[
    [ ".NETFramework,Version=v4.8.AssemblyAttributes.cs", "_8_n_e_t_framework_00_version_0av4_88_8_assembly_attributes_8cs.html", null ]
];