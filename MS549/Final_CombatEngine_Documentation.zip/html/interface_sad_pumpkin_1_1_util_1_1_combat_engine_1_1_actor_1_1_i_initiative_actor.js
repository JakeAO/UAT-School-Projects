var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor =
[
    [ "GetAllActions", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#aacc3f81d5312ea4438d0e14fb20510ea", null ],
    [ "GetInitiative", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#ad68e6b2acf4a8af3bde4b0ba93bbaec2", null ],
    [ "IsAlive", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#ae3c3049df0dee98152bb0b335d65f645", null ],
    [ "Id", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#abf59a1061fbf77ff8e4348976ad72979", null ],
    [ "Name", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#aaf14004134d82f7c28b877fb510cb289", null ],
    [ "Party", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html#a3b591c6b1d9ccbfceea607ad170d151a", null ]
];