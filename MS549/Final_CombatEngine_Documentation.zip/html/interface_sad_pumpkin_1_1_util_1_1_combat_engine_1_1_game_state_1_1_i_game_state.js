var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_i_game_state =
[
    [ "ActiveActor", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_i_game_state.html#a8856f4967eee036eb3338003a81cb862", null ],
    [ "Id", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_i_game_state.html#a7ebbc0c4353baff9220dc089a4843cbc", null ],
    [ "InitiativePreview", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_i_game_state.html#a9811f91dcf1d3f34fc86419a4babeb92", null ],
    [ "State", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_i_game_state.html#a9d3eead5607878d378bd1ae32b30afee", null ]
];