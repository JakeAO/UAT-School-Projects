var files_dup =
[
    [ "Action", "dir_cbeb2d67bd657875e65e08b576dc8007.html", "dir_cbeb2d67bd657875e65e08b576dc8007" ],
    [ "Actor", "dir_4f3b68dc77c6199308398c9d552a8742.html", "dir_4f3b68dc77c6199308398c9d552a8742" ],
    [ "CharacterControllers", "dir_8a6c5df617866b9a88d373524085013f.html", "dir_8a6c5df617866b9a88d373524085013f" ],
    [ "CostCalculators", "dir_0840f590ce4dce7f74fd93202639a4f5.html", "dir_0840f590ce4dce7f74fd93202639a4f5" ],
    [ "EffectCalculators", "dir_108b5f01ac5d58b4071ce02f90a5045e.html", "dir_108b5f01ac5d58b4071ce02f90a5045e" ],
    [ "GameState", "dir_ad5ebf44828b4c656083035f2f9871fe.html", "dir_ad5ebf44828b4c656083035f2f9871fe" ],
    [ "InitiativeQueue", "dir_0fad3f73f7f21ae8b75da5302d2d43f9.html", "dir_0fad3f73f7f21ae8b75da5302d2d43f9" ],
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "Party", "dir_cc01e94ac363d9d060a94d279ce46c6b.html", "dir_cc01e94ac363d9d060a94d279ce46c6b" ],
    [ "Properties", "dir_d051c76eebdc544d9c3d734575641c72.html", "dir_d051c76eebdc544d9c3d734575641c72" ],
    [ "RequirementCalculators", "dir_2d30c13d4103f9300ba91fbc9105f959.html", "dir_2d30c13d4103f9300ba91fbc9105f959" ],
    [ "Signals", "dir_17ba199e3bb7d1e9272dacd6fd21cb7c.html", "dir_17ba199e3bb7d1e9272dacd6fd21cb7c" ],
    [ "TargetCalculators", "dir_d8831c84aeaa7d0d789063638b5b09b2.html", "dir_d8831c84aeaa7d0d789063638b5b09b2" ],
    [ "CombatManager.cs", "_combat_manager_8cs.html", [
      [ "CombatManager", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_combat_manager.html", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_combat_manager" ]
    ] ],
    [ "CombatState.cs", "_combat_state_8cs.html", "_combat_state_8cs" ],
    [ "ICopyable.cs", "_i_copyable_8cs.html", [
      [ "ICopyable", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_i_copyable.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_i_copyable" ]
    ] ],
    [ "IIdTracked.cs", "_i_id_tracked_8cs.html", [
      [ "IIdTracked", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_i_id_tracked.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_i_id_tracked" ]
    ] ]
];