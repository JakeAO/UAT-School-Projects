var namespaces_dup =
[
    [ "SadPumpkin", "namespace_sad_pumpkin.html", "namespace_sad_pumpkin" ]
];