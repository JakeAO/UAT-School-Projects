var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor =
[
    [ "CanTarget", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor.html#abbc293647e7a78742c02da9b7b228ed7", null ]
];