var namespace_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_signals =
[
    [ "CombatComplete", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_signals_1_1_combat_complete.html", null ],
    [ "GameStateUpdated", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_signals_1_1_game_state_updated.html", null ]
];