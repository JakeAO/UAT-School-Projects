var namespace_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor =
[
    [ "IInitiativeActor", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor" ],
    [ "ITargetableActor", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor" ]
];