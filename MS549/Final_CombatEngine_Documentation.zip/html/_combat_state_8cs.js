var _combat_state_8cs =
[
    [ "CombatState", "_combat_state_8cs.html#af1488390b2d790e6a8fe104f89954e31", [
      [ "Invalid", "_combat_state_8cs.html#af1488390b2d790e6a8fe104f89954e31a4bbb8f967da6d1a610596d7257179c2b", null ],
      [ "Init", "_combat_state_8cs.html#af1488390b2d790e6a8fe104f89954e31a95b19f7739b0b7ea7d6b07586be54f36", null ],
      [ "Active", "_combat_state_8cs.html#af1488390b2d790e6a8fe104f89954e31a4d3d769b812b6faa6b76e1a8abaece2d", null ],
      [ "Completed", "_combat_state_8cs.html#af1488390b2d790e6a8fe104f89954e31a07ca5050e697392c9ed47e6453f1453f", null ]
    ] ]
];