var dir_108b5f01ac5d58b4071ce02f90a5045e =
[
    [ "IEffectCalc.cs", "_i_effect_calc_8cs.html", [
      [ "IEffectCalc", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_i_effect_calc.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_i_effect_calc" ]
    ] ],
    [ "NoEffect.cs", "_no_effect_8cs.html", [
      [ "NoEffect", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect.html", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect" ]
    ] ]
];