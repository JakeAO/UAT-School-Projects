var class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state =
[
    [ "GameState", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#ad3511978534f84cb9b552db71be5a021", null ],
    [ "Copy", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#adeeac9b887b71f4c1ea7cd562e7dc274", null ],
    [ "ActiveActor", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#a2ccaeb28807bff84c7c0af439c55e74b", null ],
    [ "Id", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#ab596f1cf93cdc2087d1d39ade8d5878f", null ],
    [ "InitiativePreview", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#abb4c0a4a88b4a43e8de760c9dd8f5860", null ],
    [ "State", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_game_state_1_1_game_state.html#a10c69cebfad90dfded03ac14d9d1746c", null ]
];