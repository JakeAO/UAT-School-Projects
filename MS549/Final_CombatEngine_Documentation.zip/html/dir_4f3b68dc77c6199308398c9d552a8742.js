var dir_4f3b68dc77c6199308398c9d552a8742 =
[
    [ "IInitiativeActor.cs", "_i_initiative_actor_8cs.html", [
      [ "IInitiativeActor", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_initiative_actor" ]
    ] ],
    [ "ITargetableActor.cs", "_i_targetable_actor_8cs.html", [
      [ "ITargetableActor", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_actor_1_1_i_targetable_actor" ]
    ] ]
];