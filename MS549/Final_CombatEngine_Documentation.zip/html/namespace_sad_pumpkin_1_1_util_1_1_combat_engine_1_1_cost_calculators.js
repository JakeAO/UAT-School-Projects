var namespace_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators =
[
    [ "ICostCalc", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators_1_1_i_cost_calc.html", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators_1_1_i_cost_calc" ],
    [ "NoCost", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators_1_1_no_cost.html", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_cost_calculators_1_1_no_cost" ]
];