var class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_self_target_calculator =
[
    [ "CanTarget", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_self_target_calculator.html#a93b7e4f716fcf9870e273a63b4035b0b", null ],
    [ "GetTargetOptions", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_self_target_calculator.html#aa68a7865431c31ef3958862bf1c98f4d", null ],
    [ "Description", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_self_target_calculator.html#a9e61183080fd2abcb0245e290df337bd", null ]
];