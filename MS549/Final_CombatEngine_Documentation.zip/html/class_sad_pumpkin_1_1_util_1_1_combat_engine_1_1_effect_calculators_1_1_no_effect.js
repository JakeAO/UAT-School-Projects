var class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect =
[
    [ "Apply", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect.html#ab5946557c1212f615f62d2168ae7b445", null ],
    [ "Description", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_no_effect.html#a83008f22576ab69c3b2ff3b1e79d74ac", null ]
];