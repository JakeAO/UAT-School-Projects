var interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_i_effect_calc =
[
    [ "Apply", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_i_effect_calc.html#aa8c2dc4dc50d9003529bab6e6234368b", null ],
    [ "Description", "interface_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_effect_calculators_1_1_i_effect_calc.html#a0ab0dd7bdb896b24cbdb7bb358a50357", null ]
];