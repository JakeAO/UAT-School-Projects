var class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_single_ally_target_calculator =
[
    [ "CanTarget", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_single_ally_target_calculator.html#ad2737a1290c69bd81e50f69384b5db8c", null ],
    [ "GetTargetOptions", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_single_ally_target_calculator.html#ae907eb5fcdc85979f3c6866dbb9bac89", null ],
    [ "Description", "class_sad_pumpkin_1_1_util_1_1_combat_engine_1_1_target_calculators_1_1_single_ally_target_calculator.html#a55bbfb48d267f84b1150b485e5748f7f", null ]
];